"""
Python for Beginners — Week 3
Exercise 4: Function: Fibonacci with Memoisation
Difficulty: Medium
Week theme: Functions, Files and Error Handling

Part of the Python Mastery Series — Volume 1
"""
import time

def validate_fib_input(n):
    if not isinstance(n, int) or n < 0:
        raise ValueError(f'n must be a non-negative integer, got: {n!r}')

def fibonacci_recursive(n):
    '''Return nth Fibonacci number using pure recursion. Slow for n > 30.'''
    validate_fib_input(n)
    if n <= 1: return n
    return fibonacci_recursive(n-1) + fibonacci_recursive(n-2)

def fibonacci_memo(n, memo=None):
    '''Return nth Fibonacci with memoisation cache. Fast.'''
    validate_fib_input(n)
    if memo is None: memo = {}   # fresh dict each top-level call
    if n in memo: return memo[n] # cache hit — return stored result
    if n <= 1: return n
    result = fibonacci_memo(n-1, memo) + fibonacci_memo(n-2, memo)
    memo[n] = result   # store result before returning
    return result

def fibonacci_iterative(n):
    '''Return nth Fibonacci using iteration. Fastest, O(n) time O(1) space.'''
    validate_fib_input(n)
    if n <= 1: return n
    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b   # parallel assignment — elegant and correct
    return b

# Test correctness
for n in [0, 1, 5, 10]:
    assert fibonacci_recursive(n) == fibonacci_iterative(n), f'Mismatch at n={n}'
print('All correctness checks passed')
# → # All correctness checks passed

# Timing comparison for n=35
n = 35
for name, fn in [('Recursive', fibonacci_recursive),
                  ('Memo',      fibonacci_memo),
                  ('Iterative', fibonacci_iterative)]:
    start  = time.perf_counter()
    result = fn(n)
    elapsed= (time.perf_counter() - start) * 1000
    print(f'{name:<12}: fib({n}) = {result}, time = {elapsed:.3f}ms')
# → # Recursive  : fib(35) = 9227465, time = 1842.5ms  (very slow!)
# → # Memo        : fib(35) = 9227465, time = 0.02ms
# → # Iterative   : fib(35) = 9227465, time = 0.01ms