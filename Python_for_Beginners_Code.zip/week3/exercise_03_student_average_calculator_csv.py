"""
Python for Beginners — Week 3
Exercise 3: Student Average Calculator (CSV)
Difficulty: Easy
Week theme: Functions, Files and Error Handling

Part of the Python Mastery Series — Volume 1
"""
import csv

GRADE_CUTOFFS = [('A',90),('B',75),('C',60),('D',50),('F',0)]

def get_grade(avg):
    for label, cutoff in GRADE_CUTOFFS:
        if avg >= cutoff:
            return label
    return 'F'

def load_student_scores(filepath):
    '''Read scores CSV, calculate average and grade, return list of dicts.'''
    results = []
    try:
        with open(filepath, 'r', encoding='utf-8', newline='') as f:
            reader = csv.DictReader(f)
            for row in reader:
                try:
                    maths   = int(row['maths'])
                    english = int(row['english'])
                    science = int(row['science'])
                    avg = round((maths + english + science) / 3, 1)
                    results.append({
                        'name':    row['name'].strip(),
                        'maths':   maths,
                        'english': english,
                        'science': science,
                        'average': avg,
                        'grade':   get_grade(avg),
                    })
                except (ValueError, KeyError) as e:
                    print(f'Warning: skipping bad row: {e}')
    except FileNotFoundError:
        print(f'File not found: {filepath}'); return []
    return results

def save_results(results, filepath):
    '''Write enriched student data to a CSV file.'''
    if not results:
        print('No results to save.'); return
    fieldnames = ['name','maths','english','science','average','grade']
    with open(filepath, 'w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results)
    print(f'Saved {len(results)} records to {filepath}')

# Create test data and demonstrate:
test_csv = 'name,maths,english,science\nAlice,88,92,79\nBob,65,58,71\nCarol,95,98,92\n'
with open('scores.csv', 'w', encoding='utf-8') as f:
    f.write(test_csv)

results = load_student_scores('scores.csv')
for r in results: print(f"{r['name']}: avg={r['average']} grade={r['grade']}")
save_results(results, 'grades.csv')
# → # Alice: avg=86.3 grade=B
# → # Bob: avg=64.7 grade=C
# → # Carol: avg=95.0 grade=A