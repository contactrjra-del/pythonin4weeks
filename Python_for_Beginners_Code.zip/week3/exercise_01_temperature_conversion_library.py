"""
Python for Beginners — Week 3
Exercise 1: Temperature Conversion Library
Difficulty: Easy
Week theme: Functions, Files and Error Handling

Part of the Python Mastery Series — Volume 1
"""
ABSOLUTE_ZERO_C = -273.15
ABSOLUTE_ZERO_K = 0
ABSOLUTE_ZERO_F = -459.67

def celsius_to_fahrenheit(c):
    '''Convert Celsius to Fahrenheit. Raises ValueError below absolute zero.'''
    if c < ABSOLUTE_ZERO_C:
        raise ValueError(f'Temperature {c}°C is below absolute zero ({ABSOLUTE_ZERO_C}°C)')
    return round(c * 9/5 + 32, 2)

def fahrenheit_to_celsius(f):
    '''Convert Fahrenheit to Celsius. Raises ValueError below absolute zero.'''
    if f < ABSOLUTE_ZERO_F:
        raise ValueError(f'Temperature {f}°F is below absolute zero ({ABSOLUTE_ZERO_F}°F)')
    return round((f - 32) * 5/9, 2)

def celsius_to_kelvin(c):
    '''Convert Celsius to Kelvin. Raises ValueError below absolute zero.'''
    if c < ABSOLUTE_ZERO_C:
        raise ValueError(f'{c}°C is below absolute zero')
    return round(c + 273.15, 2)

def kelvin_to_celsius(k):
    '''Convert Kelvin to Celsius. Raises ValueError for negative Kelvin.'''
    if k < ABSOLUTE_ZERO_K:
        raise ValueError(f'Kelvin cannot be negative: {k}')
    return round(k - 273.15, 2)

# Test all functions
print(celsius_to_fahrenheit(100))    # 212.0
print(fahrenheit_to_celsius(32))     # 0.0
print(celsius_to_kelvin(0))          # 273.15
print(kelvin_to_celsius(373.15))     # 100.0
# → # 212.0  0.0  273.15  100.0

# Demonstrate error handling:
try:
    celsius_to_fahrenheit(-300)   # below absolute zero!
except ValueError as e:
    print(f'Error: {e}')
# → # Error: Temperature -300°C is below absolute zero (-273.15°C)