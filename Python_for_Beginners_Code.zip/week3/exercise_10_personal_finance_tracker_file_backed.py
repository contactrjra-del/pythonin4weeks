"""
Python for Beginners — Week 3
Exercise 10: Personal Finance Tracker — File-Backed
Difficulty: Challenging
Week theme: Functions, Files and Error Handling

Part of the Python Mastery Series — Volume 1
"""
import csv
from datetime import datetime
from pathlib import Path

FILEPATH  = 'transactions.csv'
FIELDNAMES = ['date','type','category','description','amount']

def add_transaction(filepath, t_type, category, description, amount):
    '''Append a transaction to the CSV file.'''
    file_exists = Path(filepath).exists()
    with open(filepath, 'a', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        if not file_exists:
            writer.writeheader()   # write header only if new file
        writer.writerow({
            'date':        datetime.now().strftime('%Y-%m-%d'),
            'type':        t_type.lower(),
            'category':    category.strip(),
            'description': description.strip(),
            'amount':      round(float(amount), 2),
        })
    print(f'  Added: {t_type} £{amount:.2f} ({category})')

def load_transactions(filepath):
    '''Load all transactions from CSV, return list of typed dicts.'''
    if not Path(filepath).exists(): return []
    records = []
    with open(filepath, 'r', encoding='utf-8', newline='') as f:
        for row in csv.DictReader(f):
            try:
                records.append({**row, 'amount': float(row['amount'])})
            except (ValueError, KeyError): pass
    return records

def monthly_summary(transactions, year, month):
    '''Return {category: total} for the given year and month.'''
    prefix = f'{year}-{month:02d}'
    monthly = [t for t in transactions if t['date'].startswith(prefix)]
    summary = {}
    for t in monthly:
        key = f"{t['type']} | {t['category']}"
        summary[key] = round(summary.get(key, 0) + t['amount'], 2)
    return summary

def overall_balance(transactions):
    income   = sum(t['amount'] for t in transactions if t['type'] == 'income')
    expenses = sum(t['amount'] for t in transactions if t['type'] == 'expense')
    return round(income, 2), round(expenses, 2), round(income - expenses, 2)

def search_transactions(transactions, keyword):
    kw = keyword.lower()
    return [t for t in transactions if kw in t['description'].lower() or kw in t['category'].lower()]

# Main menu
while True:
    print('\n1)Add  2)Balance  3)Monthly  4)Search  5)All  6)Quit')
    c = input('> ').strip()
    if c == '1':
        t_type = input('Type (income/expense): ')
        cat    = input('Category: ')
        desc   = input('Description: ')
        amt    = float(input('Amount £: '))
        add_transaction(FILEPATH, t_type, cat, desc, amt)
    elif c == '2':
        txns = load_transactions(FILEPATH)
        inc, exp, bal = overall_balance(txns)
        print(f'Income: £{inc:,.2f}  Expenses: £{exp:,.2f}  Balance: £{bal:,.2f}')
    elif c == '3':
        yr = int(input('Year: ')); mo = int(input('Month (1-12): '))
        txns = load_transactions(FILEPATH)
        for k, v in monthly_summary(txns, yr, mo).items(): print(f'  {k}: £{v:,.2f}')
    elif c == '4':
        kw = input('Search: ')
        for t in search_transactions(load_transactions(FILEPATH), kw):
            print(f"  {t['date']}  {t['type']:<8}  {t['category']:<12}  £{t['amount']:>8.2f}  {t['description']}")
    elif c == '5':
        for t in load_transactions(FILEPATH):
            print(f"  {t['date']}  {t['type']:<8}  {t['category']:<12}  £{t['amount']:>8.2f}")
    elif c == '6': print('Goodbye!'); break