"""
Python for Beginners — Week 3
Mini-Project 1: CSV Sales Data Reporter
Week theme: Functions, Files and Error Handling

This is a capstone project combining all Week 3 concepts.
Run with:  python project_01_csv_sales_data_reporter.py

Part of the Python Mastery Series — Volume 1
"""
'''Sales Data Reporter — Week 3 Capstone Project'''
import csv
from datetime import datetime
from collections import defaultdict
from pathlib import Path

# ── Validation helpers ───────────────────────────────────────────────────
def is_valid_date(date_str):
    try:
        datetime.strptime(date_str, '%Y-%m-%d'); return True
    except ValueError:
        return False

def validate_row(row, row_num):
    '''Return (valid_record, error_message). error_message is None if valid.'''
    errors = []
    if not is_valid_date(row.get('date','')):
        errors.append(f'invalid date: {row.get("date")}')
    try:
        qty = int(row.get('quantity','0'))
        if qty <= 0: errors.append('quantity must be > 0')
    except ValueError: errors.append('quantity is not an integer'); qty = 0
    try:
        price = float(row.get('unit_price','0'))
        if price <= 0: errors.append('unit_price must be > 0')
    except ValueError: errors.append('unit_price is not a number'); price = 0.0
    if not row.get('region','').strip(): errors.append('region is empty')
    if not row.get('product','').strip(): errors.append('product is empty')
    if errors:
        return None, f'Row {row_num}: ' + '; '.join(errors)
    return {
        'date':       row['date'],
        'region':     row['region'].strip(),
        'product':    row['product'].strip(),
        'quantity':   qty,
        'unit_price': price,
        'month':      row['date'][:7],   # 'YYYY-MM'
    }, None

# ── Load and validate ────────────────────────────────────────────────────
def load_sales(filepath):
    records, errors = [], []
    try:
        with open(filepath, 'r', encoding='utf-8', newline='') as f:
            for row_num, row in enumerate(csv.DictReader(f), start=2):
                record, error = validate_row(row, row_num)
                if record: records.append(record)
                else: errors.append(error)
    except FileNotFoundError:
        print(f'Input file not found: {filepath}'); return [], []
    print(f'Loaded {len(records)} valid records, {len(errors)} rejected')
    for e in errors: print(f'  ⚠  {e}')
    return records, errors

# ── Analysis functions ───────────────────────────────────────────────────
def analyse_by_region(records):
    regions = defaultdict(lambda: {'revenue':0.0, 'units':0, 'transactions':0})
    for rec in records:
        r = regions[rec['region']]
        r['revenue']      += rec['total']
        r['units']        += rec['quantity']
        r['transactions'] += 1
    return {k: {**v, 'revenue': round(v['revenue'],2)} for k,v in regions.items()}

def analyse_by_product(records):
    products = defaultdict(lambda: {'revenue':0.0, 'units':0})
    for rec in records:
        p = products[rec['product']]
        p['revenue'] += rec['total']
        p['units']   += rec['quantity']
    top5 = sorted(products.items(), key=lambda x: x[1]['revenue'], reverse=True)[:5]
    return {k: {**v, 'revenue': round(v['revenue'],2)} for k,v in top5}

def analyse_monthly(records):
    months = defaultdict(float)
    for rec in records:
        months[rec['month']] += rec['total']
    return {k: round(v,2) for k,v in sorted(months.items())}

# ── Output functions ─────────────────────────────────────────────────────
def save_region_summary(region_data, filepath):
    rows = [{'region':k, **v} for k,v in sorted(region_data.items(), key=lambda x:-x[1]['revenue'])]
    with open(filepath,'w',encoding='utf-8',newline='') as f:
        w = csv.DictWriter(f, fieldnames=['region','revenue','units','transactions'])
        w.writeheader(); w.writerows(rows)
    print(f'Region summary → {filepath}')

def save_product_summary(product_data, filepath):
    rows = [{'product':k, **v} for k,v in product_data.items()]
    with open(filepath,'w',encoding='utf-8',newline='') as f:
        w = csv.DictWriter(f, fieldnames=['product','revenue','units'])
        w.writeheader(); w.writerows(rows)
    print(f'Product summary → {filepath}')

def save_monthly_trend(monthly_data, filepath):
    rows = [{'month':k, 'revenue':v} for k,v in monthly_data.items()]
    with open(filepath,'w',encoding='utf-8',newline='') as f:
        w = csv.DictWriter(f, fieldnames=['month','revenue'])
        w.writeheader(); w.writerows(rows)
    print(f'Monthly trend → {filepath}')

def print_executive_summary(records, region_data, product_data, monthly_data):
    total_rev = sum(r['total'] for r in records)
    total_units = sum(r['quantity'] for r in records)
    print(f'\n{'='*55}')
    print(f"{'EXECUTIVE SALES SUMMARY':^55}")
    print(f'{'='*55}')
    print(f'  Total records:   {len(records)}')
    print(f'  Total revenue:   £{total_rev:,.2f}')
    print(f'  Total units:     {total_units:,}')
    print(f'  Regions covered: {len(region_data)}')
    top_region = max(region_data, key=lambda k: region_data[k]['revenue'])
    print(f'  Top region:      {top_region} (£{region_data[top_region]["revenue"]:,.2f})')
    top_product = list(product_data.keys())[0]
    print(f'  Top product:     {top_product} (£{product_data[top_product]["revenue"]:,.2f})')
    print(f'{'='*55}')

# ── Main pipeline ────────────────────────────────────────────────────────
def run_sales_report(input_file):
    print(f'\nSales Data Reporter — Processing {input_file}')
    records, _ = load_sales(input_file)
    if not records: return
    region_data  = analyse_by_region(records)
    product_data = analyse_by_product(records)
    monthly_data = analyse_monthly(records)
    save_region_summary(region_data,  'region_summary.csv')
    save_product_summary(product_data, 'product_summary.csv')
    save_monthly_trend(monthly_data,   'monthly_trend.csv')
    print_executive_summary(records, region_data, product_data, monthly_data)

run_sales_report('sales.csv')
