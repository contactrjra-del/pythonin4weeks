"""
Python for Beginners — Week 3
Exercise 9: Multi-File Report Generator
Difficulty: Challenging
Week theme: Functions, Files and Error Handling

Part of the Python Mastery Series — Volume 1
"""
import csv
from pathlib import Path

def process_class(filepath):
    '''Read class CSV, enrich with average/grade/pass, return list of dicts.'''
    records = []
    with open(filepath, 'r', encoding='utf-8', newline='') as f:
        for row in csv.DictReader(f):
            scores = [int(row['maths']), int(row['english']), int(row['science'])]
            avg    = round(sum(scores)/3, 1)
            grade  = 'A' if avg>=90 else 'B' if avg>=75 else 'C' if avg>=60 else 'D' if avg>=50 else 'F'
            records.append({
                'class': Path(filepath).stem,  # 'class_a' from 'class_a.csv'
                'student_id': row['student_id'],
                'name':    row['name'].strip(),
                'maths':   int(row['maths']),
                'english': int(row['english']),
                'science': int(row['science']),
                'average': avg,
                'grade':   grade,
                'passed':  avg >= 50,
            })
    return records

def class_summary(records, class_name):
    avgs  = [r['average'] for r in records]
    top   = max(records, key=lambda r: r['average'])
    worst = min(records, key=lambda r: r['average'])
    pass_rate = sum(1 for r in records if r['passed']) / len(records) * 100
    return {
        'class': class_name, 'count': len(records),
        'average': round(sum(avgs)/len(avgs), 1),
        'top': top['name'], 'top_avg': top['average'],
        'worst': worst['name'], 'worst_avg': worst['average'],
        'pass_rate': round(pass_rate, 1),
    }

def write_school_report(summaries, all_records, output_path):
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write('SCHOOL REPORT\n' + '='*50 + '\n\n')
        for s in summaries:
            f.write(f"Class: {s['class'].upper()}\n")
            f.write(f"  Students: {s['count']}  Average: {s['average']}  Pass rate: {s['pass_rate']}%\n")
            f.write(f"  Top: {s['top']} ({s['top_avg']})  Lowest: {s['worst']} ({s['worst_avg']})\n\n")
        all_avgs = [r['average'] for r in all_records]
        school_avg = round(sum(all_avgs)/len(all_avgs), 1)
        f.write(f'SCHOOL-WIDE AVERAGE: {school_avg}\n')
    print(f'Report written to {output_path}')

def save_honour_roll(all_records, output_path, threshold=85):
    honour = [r for r in all_records if r['average'] >= threshold]
    honour = sorted(honour, key=lambda r: r['average'], reverse=True)
    fieldnames = ['class','student_id','name','average','grade']
    with open(output_path, 'w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction='ignore')
        writer.writeheader(); writer.writerows(honour)
    print(f'Honour roll: {len(honour)} students saved to {output_path}')

# ── Main pipeline ────────────────────────────────────────────────────────
class_files = ['class_a.csv', 'class_b.csv', 'class_c.csv']
all_records, summaries = [], []
for filepath in class_files:
    if Path(filepath).exists():
        records = process_class(filepath)
        all_records.extend(records)
        summaries.append(class_summary(records, Path(filepath).stem))
write_school_report(summaries, all_records, 'school_report.txt')
save_honour_roll(all_records, 'honour_roll.csv')