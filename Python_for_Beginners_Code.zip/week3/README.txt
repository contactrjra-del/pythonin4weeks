Week 3 — Functions, Files and Error Handling
============================================================

Topics covered this week:
  • Defining and calling functions
  • Scope and recursion
  • File I/O (read/write/append)
  • CSV files and data pipelines
  • try/except error handling

Files in this folder:
----------------------------------------
  exercise_01_temperature_conversion_library.py  — Temperature Conversion Library [Easy]
  exercise_02_text_file_word_counter.py  — Text File Word Counter [Easy]
  exercise_03_student_average_calculator_csv.py  — Student Average Calculator (CSV) [Easy]
  exercise_04_function_fibonacci_with_memoisation.py  — Function: Fibonacci with Memoisation [Medium]
  exercise_05_file_log_analyser.py  — File Log Analyser [Medium]
  exercise_06_recursive_directory_tree.py  — Recursive Directory Tree [Medium]
  exercise_07_safe_input_function_library.py  — Safe Input Function Library [Medium]
  exercise_08_csv_data_merger_and_deduplicator.py  — CSV Data Merger and Deduplicator [Challenging]
  exercise_09_multi_file_report_generator.py  — Multi-File Report Generator [Challenging]
  exercise_10_personal_finance_tracker_file_backed.py  — Personal Finance Tracker — File-Backed [Challenging]
  project_01_csv_sales_data_reporter.py       — CSV Sales Data Reporter
  project_02_text_file_manager_with_functions.py       — Text File Manager with Functions