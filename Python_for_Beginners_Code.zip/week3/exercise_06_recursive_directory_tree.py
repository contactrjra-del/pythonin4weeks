"""
Python for Beginners — Week 3
Exercise 6: Recursive Directory Tree
Difficulty: Medium
Week theme: Functions, Files and Error Handling

Part of the Python Mastery Series — Volume 1
"""
import os

def print_tree(path, prefix=''):
    '''Print a visual directory tree starting from path.'''
    if not os.path.exists(path):
        print(f'Path not found: {path}'); return

    # Print the root
    if prefix == '':
        print(os.path.basename(path) + '/')

    entries = sorted(os.listdir(path))
    for i, entry in enumerate(entries):
        is_last   = (i == len(entries) - 1)
        connector = '└── ' if is_last else '├── '
        entry_path = os.path.join(path, entry)

        if os.path.isdir(entry_path):
            print(prefix + connector + entry + '/')
            extension = '    ' if is_last else '│   '
            print_tree(entry_path, prefix + extension)  # recurse!
        else:
            print(prefix + connector + entry)

def count_files(path):
    '''Recursively count all files in a directory tree.'''
    if not os.path.isdir(path):
        return 1 if os.path.isfile(path) else 0
    total = 0
    for entry in os.listdir(path):
        full_path = os.path.join(path, entry)
        if os.path.isfile(full_path):
            total += 1
        elif os.path.isdir(full_path):
            total += count_files(full_path)  # recurse into subdirectory
    return total

# Create a test directory structure:
os.makedirs('data/reports', exist_ok=True)
for fname in ['data/students.csv','data/sales.csv','data/reports/jan.txt','data/reports/feb.txt']:
    open(fname,'w').close()   # create empty files

print_tree('data')
print(f'\nTotal files: {count_files("data")}')
# → # data/
# → # ├── reports/
# → # │   ├── feb.txt
# → # │   └── jan.txt
# → # ├── sales.csv
# → # └── students.csv
# → # Total files: 4