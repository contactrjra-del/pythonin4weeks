"""
Python for Beginners — Week 3
Exercise 2: Text File Word Counter
Difficulty: Easy
Week theme: Functions, Files and Error Handling

Part of the Python Mastery Series — Volume 1
"""
def count_words_in_file(filepath):
    '''Analyse a text file and return word count statistics.'''
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
    except FileNotFoundError:
        print(f'Error: File not found: {filepath}')
        return None

    lines = content.splitlines()                    # list of lines
    words = content.lower().split()                 # all words (lowercase)
    clean = [w.strip('.,!?;:\'"') for w in words] # remove punctuation
    clean = [w for w in clean if w]                # remove empty strings

    freq = {}
    for word in clean:
        freq[word] = freq.get(word, 0) + 1

    most_common = max(freq, key=freq.get) if freq else None

    return {
        'lines':       len(lines),
        'words':       len(clean),
        'chars':       len(content),
        'unique_words': len(set(clean)),
        'most_common': most_common,
        'most_common_count': freq.get(most_common, 0),
    }

# Create a test file and analyse it
sample = '''Python is great. Python is easy to learn.
It is also very powerful for data processing.
Python is used everywhere in technology today.'''
with open('sample.txt', 'w', encoding='utf-8') as f:
    f.write(sample)

stats = count_words_in_file('sample.txt')
if stats:
    for key, val in stats.items():
        print(f'  {key:<20}: {val}')
# → # lines               : 3
# → # most_common         : python  (appears 3 times)