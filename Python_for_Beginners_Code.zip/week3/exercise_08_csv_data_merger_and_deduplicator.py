"""
Python for Beginners — Week 3
Exercise 8: CSV Data Merger and Deduplicator
Difficulty: Challenging
Week theme: Functions, Files and Error Handling

Part of the Python Mastery Series — Volume 1
"""
import csv

def read_csv(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8', newline='') as f:
            return [dict(row) for row in csv.DictReader(f)]
    except FileNotFoundError:
        print(f'File not found: {filepath}'); return []

def merge_csvs(filepaths):
    '''Concatenate records from multiple CSV files.'''
    merged, source_counts = [], {}
    for fp in filepaths:
        records = read_csv(fp)
        merged.extend(records)
        source_counts[fp] = len(records)
    for fp, count in source_counts.items():
        print(f'  {fp}: {count} records')
    print(f'  Total merged: {len(merged)} records')
    return merged

def deduplicate(records, key_field):
    '''Remove duplicates by key_field; keep last occurrence.'''
    seen = {}   # {key_value: latest_record}
    for rec in records:
        key = rec.get(key_field)
        if key is not None:
            seen[key] = rec   # overwrite keeps latest
        else:
            print(f'Warning: record missing key field "{key_field}": {rec}')
    result = list(seen.values())
    removed = len(records) - len(result)
    print(f'  Deduplication: removed {removed} duplicates ({len(result)} unique)')
    return result

def filter_records(records, field, value):
    '''Return records where field == value (case-insensitive string match).'''
    result = [r for r in records if str(r.get(field,'')).lower() == str(value).lower()]
    print(f'  Filter {field}={value!r}: {len(result)} records')
    return result

def save_csv(records, filepath):
    if not records: print('No records to save.'); return
    with open(filepath, 'w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=records[0].keys())
        writer.writeheader()
        writer.writerows(records)
    print(f'Saved {len(records)} records to {filepath}')

# Create test data:
csv1 = 'employee_id,name,department,salary\nE001,Alice,Engineering,75000\nE002,Bob,HR,52000\n'
csv2 = 'employee_id,name,department,salary\nE001,Alice Smith,Engineering,78000\nE003,Carol,Engineering,88000\n'
with open('emp1.csv','w') as f: f.write(csv1)
with open('emp2.csv','w') as f: f.write(csv2)

print('\n=== Pipeline ===')
merged   = merge_csvs(['emp1.csv', 'emp2.csv'])
unique   = deduplicate(merged, 'employee_id')
eng_only = filter_records(unique, 'department', 'Engineering')
save_csv(eng_only, 'engineering_staff.csv')
for r in eng_only: print(r)
# → # {'employee_id':'E001','name':'Alice Smith','department':'Engineering','salary':'78000'}
# → # {'employee_id':'E003','name':'Carol','department':'Engineering','salary':'88000'}