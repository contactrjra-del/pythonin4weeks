"""
Python for Beginners — Week 3
Exercise 7: Safe Input Function Library
Difficulty: Medium
Week theme: Functions, Files and Error Handling

Part of the Python Mastery Series — Volume 1
"""
def get_int(prompt, min_val=None, max_val=None):
    '''Get an integer from the user within optional bounds.'''
    while True:
        raw = input(prompt).strip()
        try:
            value = int(raw)
        except ValueError:
            print(f'  Please enter a whole number (got: {raw!r})')
            continue
        if min_val is not None and value < min_val:
            print(f'  Must be at least {min_val}.')
        elif max_val is not None and value > max_val:
            print(f'  Must be at most {max_val}.')
        else:
            return value

def get_float(prompt, min_val=None, max_val=None):
    '''Get a float from the user within optional bounds.'''
    while True:
        try:
            value = float(input(prompt).strip())
            if min_val is not None and value < min_val:
                print(f'  Must be >= {min_val}.')
            elif max_val is not None and value > max_val:
                print(f'  Must be <= {max_val}.')
            else:
                return value
        except ValueError:
            print('  Please enter a number.')

def get_choice(prompt, choices):
    '''Get a value that must be in the choices list.'''
    display = '/'.join(str(c) for c in choices)
    while True:
        val = input(f'{prompt} ({display}): ').strip().lower()
        if val in [str(c).lower() for c in choices]:
            return val
        print(f'  Please choose one of: {display}')

def get_yes_no(prompt):
    '''Get y/n from user. Returns True for yes, False for no.'''
    while True:
        answer = input(f'{prompt} (y/n): ').strip().lower()
        if answer in ('y', 'yes'): return True
        if answer in ('n', 'no'):  return False
        print('  Please enter y or n.')

def get_non_empty_string(prompt, max_len=None):
    '''Get a non-empty string within optional max length.'''
    while True:
        val = input(prompt).strip()
        if not val:
            print('  Input cannot be empty.'); continue
        if max_len and len(val) > max_len:
            print(f'  Max {max_len} characters (you entered {len(val)}).')
            continue
        return val

# Demo:
name = get_non_empty_string('Enter name: ', max_len=50)
age  = get_int('Enter age: ', min_val=0, max_val=150)
dept = get_choice('Department', ['IT','HR','Finance','Operations'])
active = get_yes_no('Is account active?')
print(f'{name}, {age}, {dept}, active={active}')