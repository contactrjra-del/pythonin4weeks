"""
Python for Beginners — Week 3
Mini-Project 2: Text File Manager with Functions
Week theme: Functions, Files and Error Handling

This is a capstone project combining all Week 3 concepts.
Run with:  python project_02_text_file_manager_with_functions.py

Part of the Python Mastery Series — Volume 1
"""
'''Text File Manager — Week 3 Project'''
from pathlib import Path
import shutil

def create(filepath, content):
    '''Create a new file. Raises FileExistsError if file already exists.'''
    p = Path(filepath)
    if p.exists():
        raise FileExistsError(f'File already exists: {filepath}. Use append to add content.')
    p.write_text(content, encoding='utf-8')
    print(f'Created: {filepath} ({len(content)} chars)')

def append_to(filepath, content):
    '''Append content to an existing file (or create if missing).'''
    with open(filepath, 'a', encoding='utf-8') as f:
        if not content.endswith('\n'):
            content += '\n'         # ensure content ends with newline
        f.write(content)
    print(f'Appended {len(content)} chars to {filepath}')

def read_file(filepath):
    '''Return file content as a string with line numbers.'''
    try:
        lines = Path(filepath).read_text(encoding='utf-8').splitlines()
        result = []
        for i, line in enumerate(lines, start=1):
            result.append(f'{i:4d} | {line}')
        return '\n'.join(result)
    except FileNotFoundError:
        return f'Error: File not found: {filepath}'

def search_in_file(filepath, keyword):
    '''Return list of (line_num, line) where keyword appears (case-insensitive).'''
    try:
        lines = Path(filepath).read_text(encoding='utf-8').splitlines()
        matches = [(i+1, line) for i, line in enumerate(lines)
                   if keyword.lower() in line.lower()]
        print(f'Found {len(matches)} match(es) for {keyword!r} in {filepath}')
        return matches
    except FileNotFoundError:
        print(f'File not found: {filepath}'); return []

def replace_in_file(filepath, old, new):
    '''Replace all occurrences of old with new in file. Returns count of replacements.'''
    try:
        content = Path(filepath).read_text(encoding='utf-8')
        count   = content.count(old)
        if count == 0:
            print(f'  {old!r} not found in {filepath}')
            return 0
        Path(filepath).write_text(content.replace(old, new), encoding='utf-8')
        print(f'  Replaced {count} occurrence(s) of {old!r} with {new!r}')
        return count
    except FileNotFoundError:
        print(f'File not found: {filepath}'); return 0

def count_statistics(filepath):
    '''Return dict of word, line, character, and unique word counts.'''
    try:
        content = Path(filepath).read_text(encoding='utf-8')
        words   = content.lower().split()
        clean   = [w.strip('.,!?;:') for w in words if w.strip('.,!?;:')]
        return {
            'lines':   len(content.splitlines()),
            'words':   len(clean),
            'chars':   len(content),
            'unique':  len(set(clean)),
        }
    except FileNotFoundError:
        print(f'File not found: {filepath}'); return None

def backup(filepath):
    '''Copy file to filepath.bak. Raises FileNotFoundError if source missing.'''
    src = Path(filepath)
    if not src.exists():
        raise FileNotFoundError(f'Cannot backup: {filepath} not found')
    dst = Path(str(filepath) + '.bak')
    shutil.copy2(str(src), str(dst))
    print(f'Backed up {filepath} → {dst}')

def merge_files(filepaths, output):
    '''Concatenate multiple text files into one output file with section headers.'''
    merged = []
    for fp in filepaths:
        try:
            content = Path(fp).read_text(encoding='utf-8')
            merged.append(f'\n--- {fp} ---\n{content}')
        except FileNotFoundError:
            print(f'  Warning: {fp} not found, skipped')
    Path(output).write_text('\n'.join(merged), encoding='utf-8')
    print(f'Merged {len(merged)} file(s) into {output}')

def main():
    '''Interactive menu for the text file manager.'''
    print('\n=== Text File Manager ===')
    while True:
        print('\n1)Create 2)Append 3)Read 4)Search 5)Replace 6)Stats 7)Backup 8)Merge 9)Quit')
        choice = input('> ').strip()

        if choice == '1':
            fp = input('Filename: ')
            content = input('Content: ')
            try:
                create(fp, content)
            except FileExistsError as e:
                print(f'  Error: {e}')
        elif choice == '2':
            fp = input('Filename: ')
            content = input('Content to append: ')
            append_to(fp, content)
        elif choice == '3':
            fp = input('Filename: ')
            print(read_file(fp))
        elif choice == '4':
            fp = input('Filename: ')
            kw = input('Search keyword: ')
            for line_num, line in search_in_file(fp, kw):
                print(f'  Line {line_num}: {line}')
        elif choice == '5':
            fp  = input('Filename: ')
            old = input('Text to replace: ')
            new = input('Replace with: ')
            replace_in_file(fp, old, new)
        elif choice == '6':
            fp = input('Filename: ')
            stats = count_statistics(fp)
            if stats:
                for k, v in stats.items(): print(f'  {k:<10}: {v}')
        elif choice == '7':
            fp = input('Filename to backup: ')
            try:
                backup(fp)
            except FileNotFoundError as e:
                print(f'  Error: {e}')
        elif choice == '8':
            raw = input('Files to merge (comma-separated): ')
            fps = [fp.strip() for fp in raw.split(',')]
            out = input('Output filename: ')
            merge_files(fps, out)
        elif choice == '9':
            print('Goodbye!'); break

main()
