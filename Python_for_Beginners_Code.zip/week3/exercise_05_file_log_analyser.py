"""
Python for Beginners — Week 3
Exercise 5: File Log Analyser
Difficulty: Medium
Week theme: Functions, Files and Error Handling

Part of the Python Mastery Series — Volume 1
"""
def parse_log_file(filepath):
    '''Parse a log file into a list of structured dicts.'''
    logs = []
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, start=1):
                line = line.strip()
                if not line: continue
                parts = line.split(maxsplit=3)  # split into max 4 parts
                if len(parts) < 4:
                    print(f'Warning: malformed line {line_num}: {line!r}')
                    continue
                logs.append({
                    'date':    parts[0],
                    'time':    parts[1],
                    'level':   parts[2].upper(),
                    'message': parts[3],
                })
    except FileNotFoundError:
        print(f'Log file not found: {filepath}'); return []
    return logs

def filter_by_level(logs, level):
    return [log for log in logs if log['level'] == level.upper()]

def count_by_level(logs):
    counts = {}
    for log in logs:
        counts[log['level']] = counts.get(log['level'], 0) + 1
    return counts

def get_errors(logs):
    return [log['message'] for log in logs if log['level'] == 'ERROR']

def write_report(logs, output_path):
    counts = count_by_level(logs)
    errors = get_errors(logs)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write('LOG ANALYSIS REPORT\n' + '='*40 + '\n')
        f.write(f'Total log entries: {len(logs)}\n\n')
        f.write('Level counts:\n')
        for level, count in sorted(counts.items()):
            f.write(f'  {level:<10}: {count}\n')
        if errors:
            f.write(f'\nError messages ({len(errors)}):\n')
            for err in errors:
                f.write(f'  - {err}\n')
    print(f'Report written to {output_path}')