"""
Python for Beginners — Week 1
Exercise 7: Number Properties Analyser
Difficulty: Medium
Week theme: Foundations — Variables, Types, Strings, Conditionals

Part of the Python Mastery Series — Volume 1
"""
n = int(input('Enter an integer: '))

# Sign check
if n > 0: sign = 'Positive'
elif n < 0: sign = 'Negative'
else: sign = 'Zero'

# Even / Odd
parity = 'Even' if n % 2 == 0 else 'Odd'

# Prime check
def is_prime(num):
    if num < 2: return False
    if num == 2: return True
    if num % 2 == 0: return False
    i = 3
    while i * i <= num:    # only need to check up to sqrt(num)
        if num % i == 0: return False
        i += 2
    return True

# Digital root
def digital_root(num):
    num = abs(num)   # handle negatives
    while num >= 10:
        num = sum(int(d) for d in str(num))
    return num

print(f'Number:       {n}')
print(f'Sign:         {sign}')
print(f'Parity:       {parity}')
print(f'Prime:        {is_prime(n)}')
print(f'Digital root: {digital_root(n)}')