"""
Python for Beginners — Week 1
Exercise 10: Text Analyser — Sentence Statistics
Difficulty: Challenging
Week theme: Foundations — Variables, Types, Strings, Conditionals

Part of the Python Mastery Series — Volume 1
"""
POSITIVE = {'good','great','excellent','happy','love','wonderful','amazing','fantastic'}
NEGATIVE = {'bad','terrible','awful','sad','hate','horrible','dreadful','poor'}

text = input('Enter a paragraph: ')

# ── Basic counts ─────────────────────────────────────────────────────────
char_count   = len(text.replace(' ', ''))
words        = text.split()
word_count   = len(words)
sent_count   = sum(1 for c in text if c in '.!?')

# ── Clean words (remove punctuation, lowercase) ───────────────────────────
clean_words = [w.lower().strip('.,!?;:\'"') for w in words]

# ── Average word length ──────────────────────────────────────────────────
avg_len = sum(len(w) for w in clean_words) / word_count if word_count > 0 else 0

# ── Most frequent letter ─────────────────────────────────────────────────
letter_counts = {}
for ch in text.lower():
    if ch.isalpha():
        letter_counts[ch] = letter_counts.get(ch, 0) + 1
most_common = max(letter_counts, key=letter_counts.get) if letter_counts else 'N/A'

# ── Longest word ────────────────────────────────────────────────────────
longest = max(clean_words, key=len) if clean_words else 'N/A'

# ── Sentiment ───────────────────────────────────────────────────────────
pos_count = sum(1 for w in clean_words if w in POSITIVE)
neg_count = sum(1 for w in clean_words if w in NEGATIVE)
if pos_count > neg_count:   sentiment = f'Positive ({pos_count} positive words)'
elif neg_count > pos_count: sentiment = f'Negative ({neg_count} negative words)'
else:                       sentiment = 'Neutral / Mixed'

print(f'\nTEXT ANALYSIS REPORT')
print(f'Characters (no spaces): {char_count}')
print(f'Words:                  {word_count}')
print(f'Sentences:              {sent_count}')
print(f'Avg word length:        {avg_len:.1f} chars')
print(f'Most frequent letter:   {most_common!r}')
print(f'Longest word:           {longest!r}')
print(f'Sentiment:              {sentiment}')