"""
Python for Beginners — Week 1
Exercise 8: Simple ATM Simulator
Difficulty: Challenging
Week theme: Foundations — Variables, Types, Strings, Conditionals

Part of the Python Mastery Series — Volume 1
"""
CORRECT_PIN = '4321'
balance     = 1500.0
MAX_ATTEMPTS = 3

# ── PIN verification ───────────────────────────────────────
attempts   = 0
logged_in  = False

while attempts < MAX_ATTEMPTS:
    pin = input(f'Enter PIN (attempt {attempts+1}/{MAX_ATTEMPTS}): ')
    if pin == CORRECT_PIN:
        logged_in = True
        print('Login successful.\n')
        break
    else:
        attempts += 1
        remaining = MAX_ATTEMPTS - attempts
        if remaining > 0:
            print(f'Incorrect PIN. {remaining} attempt(s) remaining.')

if not logged_in:
    print('Account locked after 3 failed attempts. Please contact your bank.')
else:
    # ── ATM Menu ────────────────────────────────────────────
    while True:
        print('\n  1) Check Balance')
        print('  2) Deposit')
        print('  3) Withdraw')
        print('  4) Exit')
        choice = input('Choose: ').strip()

        if choice == '1':
            print(f'  Balance: £{balance:,.2f}')

        elif choice == '2':
            amount = float(input('  Deposit amount: £'))
            if amount < 1:
                print('  Minimum deposit is £1.00')
            else:
                balance += amount
                print(f'  Deposited £{amount:.2f}. New balance: £{balance:,.2f}')

        elif choice == '3':
            amount = float(input('  Withdraw amount (multiples of £10): £'))
            if amount % 10 != 0:
                print('  Withdrawals must be in multiples of £10.')
            elif amount > balance:
                print(f'  Insufficient funds. Balance: £{balance:,.2f}')
            else:
                balance -= amount
                print(f'  Dispensed £{amount:.0f}. New balance: £{balance:,.2f}')

        elif choice == '4':
            print('  Thank you. Goodbye!')
            break
        else:
            print('  Invalid choice. Please enter 1, 2, 3, or 4.')