"""
Python for Beginners — Week 1
Exercise 3: String Inspector
Difficulty: Easy
Week theme: Foundations — Variables, Types, Strings, Conditionals

Part of the Python Mastery Series — Volume 1
"""
sentence = input('Type a sentence: ')

char_count = len(sentence)
word_count = len(sentence.split())
starts_capital = sentence[0].isupper() if sentence else False
reversed_sentence = sentence[::-1]

print(f'Uppercase:      {sentence.upper()}')
print(f'Characters:     {char_count}')
print(f'Words:          {word_count}')
print(f'Starts capital: {starts_capital}')
print(f'Reversed:       {reversed_sentence}')