"""
Python for Beginners — Week 1
Mini-Project 1: Bank Account Balance Checker & Advisor
Week theme: Foundations — Variables, Types, Strings, Conditionals

This is a capstone project combining all Week 1 concepts.
Run with:  python project_01_bank_account_balance_checker_advisor.py

Part of the Python Mastery Series — Volume 1
"""
# ═══════════════════════════════════════════════════════
# PROJECT 1: Bank Account Balance Checker & Advisor
# Concepts: variables · data types · input · f-strings
#            if/elif/else · string methods · arithmetic
# ═══════════════════════════════════════════════════════

# ── Constants ──────────────────────────────────────────
INTEREST_RATES = {
    'current':  0.005,   # 0.5%
    'savings':  0.035,   # 3.5%
    'isa':      0.040,   # 4.0%
}
MONTHLY_BUDGET = 1500
VALID_TYPES    = {'current', 'savings', 'isa'}

# ── Welcome banner ─────────────────────────────────────
print('=' * 50)
print('   BANK ACCOUNT BALANCE CHECKER & ADVISOR')
print('=' * 50)

# ── Gather user information ─────────────────────────
name = input('Account holder name: ').strip().title()
balance = float(input('Current balance (£): '))

# ── Validate account type (loop until valid) ─────────
while True:
    acc_type_raw = input('Account type (Current/Savings/ISA): ').strip().lower()
    if acc_type_raw in VALID_TYPES:
        acc_type = acc_type_raw
        break
    else:
        print(f"  Invalid type '{acc_type_raw}'. Please enter Current, Savings, or ISA.")

acc_type_display = acc_type.title()   # 'Current', 'Savings', 'Isa'
if acc_type == 'isa': acc_type_display = 'ISA'   # Fix capitalisation

# ── Balance classification ──────────────────────────
if balance < 0:
    category = 'Overdrawn'
    message  = 'Your account is overdrawn. Contact your bank immediately.'
    emoji    = '🔴'
elif balance < 100:
    category = 'Critical'
    message  = 'Balance critically low. Prioritise building a safety buffer.'
    emoji    = '🟠'
elif balance < 500:
    category = 'Low'
    message  = 'Below recommended emergency fund level. Focus on saving.'
    emoji    = '🟡'
elif balance < 5000:
    category = 'Healthy'
    message  = 'Good standing. Consider allocating surplus to investments.'
    emoji    = '🟢'
else:
    category = 'Excellent'
    message  = 'Strong financial position. Review long-term investment options.'
    emoji    = '✨'

# ── Financial calculations ──────────────────────────
rate           = INTEREST_RATES[acc_type]
interest_1yr   = balance * rate if balance > 0 else 0
months_covered = balance / MONTHLY_BUDGET if balance > 0 else 0

# ── Report ──────────────────────────────────────────
print(f'\n{'='*50}')
print(f'  ACCOUNT SUMMARY FOR {name.upper()}')
print(f'{'='*50}')
print(f'  Account type:  {acc_type_display}')
print(f'  Balance:       £{balance:>10,.2f}')
print(f'  Status:        {emoji} {category}')
print(f'  Assessment:    {message}')
print(f'{'─'*50}')
print(f'  Interest rate: {rate:.1%} per annum')
print(f'  1-yr interest: £{interest_1yr:>10,.2f}')
print(f'  Budget months: {months_covered:.1f} months of £{MONTHLY_BUDGET:,}/month')
print(f'{'─'*50}')

# ── Personalised action points ──────────────────────
print('  RECOMMENDED ACTIONS:')

if category == 'Overdrawn':
    print('  1. Call your bank today to discuss an overdraft arrangement')
    print('  2. Review all direct debits and cancel non-essentials')
    print('  3. Look into a 0% credit card for short-term bridging')
elif category == 'Critical':
    print('  1. Set up a £50/month standing order to a savings account')
    print('  2. Track all spending for 30 days — identify and eliminate waste')
    print('  3. Check eligibility for government savings incentives')
elif category == 'Low' and acc_type == 'current':
    print('  1. Open a savings account and automate a monthly transfer')
    print(f'  2. Target: £500 safety buffer (£{500-balance:.0f} to go)')
    print('  3. Review regular outgoings for savings opportunities')
elif category == 'Healthy' and acc_type == 'current':
    print(f'  1. Move £{min(balance*0.2, 20000):.0f} to an ISA (4.0% tax-free)')
    print('  2. Set a monthly savings goal: 20% of income')
    print('  3. Review pension contributions for tax efficiency')
elif category in ('Healthy', 'Excellent') and acc_type == 'savings':
    print('  1. Ensure savings are in highest-rate account available')
    print(f'  2. Consider ISA for up to £20,000/year tax-free at 4.0%')
    print('  3. Review investment options: index funds, bonds, property')
else:
    print('  1. Continue regular contributions to this account')
    print('  2. Review interest rate annually — switch if better rates available')
    print('  3. Consult a financial adviser for personalised guidance')

print(f'{'='*50}')
