"""
Python for Beginners — Week 1
Exercise 9: Mortgage Payment Calculator
Difficulty: Challenging
Week theme: Foundations — Variables, Types, Strings, Conditionals

Part of the Python Mastery Series — Volume 1
"""
principal    = float(input('Loan amount (£): '))
annual_rate  = float(input('Annual interest rate (%): '))
years        = int(input('Loan term (years): '))

n = years * 12   # total number of monthly payments

if annual_rate == 0:
    monthly_payment = principal / n
else:
    r = annual_rate / 12 / 100   # monthly rate as decimal
    monthly_payment = principal * (r * (1 + r)**n) / ((1 + r)**n - 1)

total_paid    = monthly_payment * n
total_interest = total_paid - principal

print(f'\n{'='*40}')
print(f'  MORTGAGE SUMMARY')
print(f'{'='*40}')
print(f'  Principal:        £{principal:>12,.2f}')
print(f'  Rate:              {annual_rate:>11.2f}%')
print(f'  Term:              {years:>10} years')
print(f'  Monthly payment:  £{monthly_payment:>12,.2f}')
print(f'  Total paid:       £{total_paid:>12,.2f}')
print(f'  Total interest:   £{total_interest:>12,.2f}')
print(f'{'='*40}')