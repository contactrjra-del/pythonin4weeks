"""
Python for Beginners — Week 1
Exercise 5: Leap Year Detector
Difficulty: Medium
Week theme: Foundations — Variables, Types, Strings, Conditionals

Part of the Python Mastery Series — Volume 1
"""
year = int(input('Enter a year: '))

if year % 400 == 0:
    is_leap = True
    reason  = f'{year} is divisible by 400'
elif year % 100 == 0:
    is_leap = False
    reason  = f'{year} is divisible by 100 but not 400'
elif year % 4 == 0:
    is_leap = True
    reason  = f'{year} is divisible by 4 (and not by 100)'
else:
    is_leap = False
    reason  = f'{year} is not divisible by 4'

result = 'IS' if is_leap else 'is NOT'
print(f'{year} {result} a leap year.')
print(f'Reason: {reason}')