"""
Python for Beginners — Week 1
Mini-Project 2: Username & Password Generator
Week theme: Foundations — Variables, Types, Strings, Conditionals

This is a capstone project combining all Week 1 concepts.
Run with:  python project_02_username_password_generator.py

Part of the Python Mastery Series — Volume 1
"""
# ═══════════════════════════════════════════════════════
# PROJECT 2: Username & Password Generator
# Concepts: strings · slicing · methods · f-strings
#            if/elif/else · arithmetic · type conversion
# ═══════════════════════════════════════════════════════
import random   # only one import needed — taught in Week 4 but valid here
import string

SPECIAL_CHARS = '!@#$%^&*'

# ── Gather information ──────────────────────────────────────────────────
print('\n' + '='*55)
print('   USERNAME & PASSWORD GENERATOR')
print('='*55)

first_name  = input('First name:  ').strip()
last_name   = input('Last name:   ').strip()
birth_year  = input('Birth year:  ').strip()
fav_number  = input('Favourite number (1-9): ').strip()

# Basic validation
if not first_name or not last_name:
    print('Name fields cannot be empty.'); exit()
if not birth_year.isdigit() or len(birth_year) != 4:
    print('Please enter a 4-digit birth year.'); exit()
if not fav_number.isdigit() or not (1 <= int(fav_number) <= 9):
    print('Favourite number must be 1-9.'); exit()

# Password length
while True:
    pw_len_str = input('Password length (8-20): ').strip()
    if pw_len_str.isdigit() and 8 <= int(pw_len_str) <= 20:
        pw_length = int(pw_len_str)
        break
    print('  Please enter a number between 8 and 20.')

# ── Username generation ─────────────────────────────────────────────────
fn = first_name.capitalize()  # normalise case
ln = last_name.capitalize()
yr = birth_year[-2:]          # last 2 digits of year
num = fav_number

# Primary username
primary = fn[:3] + ln[:3] + yr + num

# Alternative usernames
alt1 = fn[0] + ln[0] + birth_year + num            # initials + full year + num
alt2 = fn[::-1].capitalize()[:3] + num + yr        # reversed first name + num + yr
alt3 = fn[:4] + ln[-2:] + yr if len(ln) >= 2 else fn[:4] + ln + yr

# ── Password generation ─────────────────────────────────────────────────
# Fixed components from user data
fixed_part = (fn[0].upper() +          # first letter of first name (upper)
              ln[-1].upper() +          # last letter of last name (upper)
              birth_year[::-1] +        # birth year reversed
              num +                     # favourite number
              random.choice(SPECIAL_CHARS))  # one special char

# Fill remaining length with random chars (uppercase + digits + special)
pool     = string.ascii_uppercase + string.digits + SPECIAL_CHARS
needed   = pw_length - len(fixed_part)
random_part = ''.join(random.choice(pool) for _ in range(max(needed, 0)))

# Combine and shuffle the full password
all_chars = list(fixed_part + random_part)
random.shuffle(all_chars)
password  = ''.join(all_chars)[:pw_length]

# ── Password strength check ─────────────────────────────────────────────
strength_checks = {
    'Length OK':       len(password) >= 8,
    'Has uppercase':   any(c.isupper() for c in password),
    'Has lowercase':   any(c.islower() for c in password),
    'Has digit':       any(c.isdigit() for c in password),
    'Has special':     any(c in SPECIAL_CHARS for c in password),
}
score  = sum(strength_checks.values())
level  = 'Weak' if score < 3 else 'Moderate' if score < 5 else 'Strong'

# ── Output report ───────────────────────────────────────────────────────
print(f'\n{'='*55}')
print(f'  CREDENTIALS REPORT FOR {fn.upper()} {ln.upper()}')
print(f'{'='*55}')
print(f'  PRIMARY USERNAME:   {primary}')
print(f'  Alternative 1:     {alt1}')
print(f'  Alternative 2:     {alt2}')
print(f'  Alternative 3:     {alt3}')
print(f'{'─'*55}')
print(f'  GENERATED PASSWORD: {password}')
print(f'  Length:             {len(password)} characters')
print(f'  Strength:           {level} ({score}/5 criteria)')
for crit, result in strength_checks.items():
    print(f"    {'✅' if result else '❌'} {crit}")
print(f'{'='*55}')
print('  ⚠  Store your credentials securely — never share your password!')
print(f'{'='*55}')
