"""
Python for Beginners — Week 1
Exercise 2: Temperature Converter
Difficulty: Easy
Week theme: Foundations — Variables, Types, Strings, Conditionals

Part of the Python Mastery Series — Volume 1
"""
celsius    = float(input('Enter temperature in Celsius: '))
fahrenheit = celsius * 9/5 + 32
kelvin     = celsius + 273.15

print(f'Celsius:    {celsius:.1f}°C')
print(f'Fahrenheit: {fahrenheit:.1f}°F')
print(f'Kelvin:     {kelvin:.1f}K')