"""
Python for Beginners — Week 1
Exercise 6: Password Strength Checker
Difficulty: Medium
Week theme: Foundations — Variables, Types, Strings, Conditionals

Part of the Python Mastery Series — Volume 1
"""
SPECIAL_CHARS = '!@#$%^&*'

password = input('Enter a password: ')

# Check each criterion
criteria = {
    'Length >= 8':        len(password) >= 8,
    'Has uppercase':      any(c.isupper() for c in password),
    'Has lowercase':      any(c.islower() for c in password),
    'Has digit':          any(c.isdigit() for c in password),
    'Has special char':   any(c in SPECIAL_CHARS for c in password),
}

print('\nPassword Strength Report:')
passed = 0
for criterion, result in criteria.items():
    symbol  = '✅' if result else '❌'
    passed += 1 if result else 0
    print(f'  {symbol} {criterion}')

if passed < 3:
    strength = 'Weak'
elif passed < 5:
    strength = 'Moderate'
else:
    strength = 'Strong'

print(f'\nOverall: {strength} ({passed}/5 criteria met)')