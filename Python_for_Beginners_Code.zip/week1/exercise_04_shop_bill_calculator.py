"""
Python for Beginners — Week 1
Exercise 4: Shop Bill Calculator
Difficulty: Medium
Week theme: Foundations — Variables, Types, Strings, Conditionals

Part of the Python Mastery Series — Volume 1
"""
# Item prices
APPLE_PRICE = 0.45
BREAD_PRICE = 1.20
MILK_PRICE  = 0.89
VAT_RATE    = 0.20
DISCOUNT_THRESHOLD = 10.00
DISCOUNT_RATE      = 0.05

apples = int(input('How many apples? '))
breads = int(input('How many loaves of bread? '))
milks  = int(input('How many pints of milk? '))

apple_cost = apples * APPLE_PRICE
bread_cost = breads * BREAD_PRICE
milk_cost  = milks  * MILK_PRICE
subtotal   = apple_cost + bread_cost + milk_cost

# Apply discount if threshold met
if subtotal > DISCOUNT_THRESHOLD:
    discount = subtotal * DISCOUNT_RATE
    subtotal -= discount
    print(f'Loyalty discount applied: -£{discount:.2f}')

vat   = subtotal * VAT_RATE
total = subtotal + vat

print('', '='*35, sep='')
print('        RECEIPT')
print('='*35)
print(f'  Apples x{apples:<2}       £{apple_cost:>6.2f}')
print(f'  Bread  x{breads:<2}       £{bread_cost:>6.2f}')
print(f'  Milk   x{milks:<2}        £{milk_cost:>6.2f}')
print('-'*35)
print(f'  Subtotal          £{subtotal:>6.2f}')
print(f'  VAT (20%)         £{vat:>6.2f}')
print('='*35)
print(f'  TOTAL             £{total:>6.2f}')
print('='*35)