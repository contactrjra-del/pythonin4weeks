"""
Python for Beginners — Week 1
Exercise 1: Personal Introduction Program
Difficulty: Easy
Week theme: Foundations — Variables, Types, Strings, Conditionals

Part of the Python Mastery Series — Volume 1
"""
# Personal Introduction Program
name = input('Enter your name: ')
age  = int(input('Enter your age: '))
city = input('Enter your city: ')

birth_year     = 2024 - age
centenary_year = birth_year + 100

print(f'Hello! My name is {name}.')
print(f'I am {age} years old and I live in {city}.')
print(f'I was born in {birth_year}.')
print(f'I will turn 100 in the year {centenary_year}.')