Week 1 — Foundations — Variables, Types, Strings, Conditionals
============================================================

Topics covered this week:
  • Variables and data types
  • Strings and f-strings
  • Numbers and arithmetic
  • Conditionals (if/elif/else)
  • User input and output

Files in this folder:
----------------------------------------
  exercise_01_personal_introduction_program.py  — Personal Introduction Program [Easy]
  exercise_02_temperature_converter.py  — Temperature Converter [Easy]
  exercise_03_string_inspector.py  — String Inspector [Easy]
  exercise_04_shop_bill_calculator.py  — Shop Bill Calculator [Medium]
  exercise_05_leap_year_detector.py  — Leap Year Detector [Medium]
  exercise_06_password_strength_checker.py  — Password Strength Checker [Medium]
  exercise_07_number_properties_analyser.py  — Number Properties Analyser [Medium]
  exercise_08_simple_atm_simulator.py  — Simple ATM Simulator [Challenging]
  exercise_09_mortgage_payment_calculator.py  — Mortgage Payment Calculator [Challenging]
  exercise_10_text_analyser_sentence_statistics.py  — Text Analyser — Sentence Statistics [Challenging]
  project_01_bank_account_balance_checker_advisor.py       — Bank Account Balance Checker & Advisor
  project_02_username_password_generator.py       — Username & Password Generator