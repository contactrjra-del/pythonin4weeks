"""
Python for Beginners — Week 2
Exercise 3: Set Operations — Mailing List Deduplication
Difficulty: Easy
Week theme: Collections and Loops — Lists, Dicts, Sets, Loops, Comprehensions

Part of the Python Mastery Series — Volume 1
"""
list1 = ['alice@mail.com','bob@mail.com','carol@mail.com','alice@mail.com','dave@mail.com']
list2 = ['bob@mail.com','eve@mail.com','carol@mail.com','frank@mail.com','bob@mail.com']

set1 = set(list1)   # {'alice@mail.com','bob@mail.com','carol@mail.com','dave@mail.com'}
set2 = set(list2)   # {'bob@mail.com','carol@mail.com','eve@mail.com','frank@mail.com'}

all_unique   = set1 | set2   # union
in_both      = set1 & set2   # intersection
list1_only   = set1 - set2   # difference

print(f'All unique subscribers ({len(all_unique)}):')
for email in sorted(all_unique):
    print(f'  {email}')
print(f'\nIn both lists: {sorted(in_both)}')
print(f'List 1 only:  {sorted(list1_only)}')
print(f'Total unique: {len(all_unique)}')
# → # All unique subscribers (6):
# → # In both lists: ['bob@mail.com', 'carol@mail.com']
# → # List 1 only:   ['alice@mail.com', 'dave@mail.com']
# → # Total unique:  6