"""
Python for Beginners — Week 2
Exercise 5: Dictionary — Word Frequency Counter
Difficulty: Medium
Week theme: Collections and Loops — Lists, Dicts, Sets, Loops, Comprehensions

Part of the Python Mastery Series — Volume 1
"""
sentence = input('Enter a sentence: ')

# Clean and split
words = sentence.lower().split()
clean_words = [w.strip('.,!?;:\'"') for w in words if w.strip('.,!?;:\'"')]

# Count frequencies
frequency = {}
for word in clean_words:
    frequency[word] = frequency.get(word, 0) + 1

# Sort by count descending
sorted_words = sorted(frequency.items(), key=lambda item: item[1], reverse=True)

print(f'\nWord Frequency Analysis:')
print(f'  {'Word':<15}  Count')
print('  ' + '─'*22)
for word, count in sorted_words:
    bar = '█' * count
    print(f'  {word:<15}  {count}  {bar}')

most_common = sorted_words[0][0]
print(f'\nMost common word:  "{most_common}" ({frequency[most_common]}×)')
print(f'Unique words:       {len(frequency)}')

repeated = [w for w, c in frequency.items() if c > 1]
print(f'Repeated words:    {repeated if repeated else "None"}')