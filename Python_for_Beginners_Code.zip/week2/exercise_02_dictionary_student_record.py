"""
Python for Beginners — Week 2
Exercise 2: Dictionary — Student Record
Difficulty: Easy
Week theme: Collections and Loops — Lists, Dicts, Sets, Loops, Comprehensions

Part of the Python Mastery Series — Volume 1
"""
student = {
    'name':          'Alice Johnson',
    'age':           20,
    'subjects':      ['Mathematics', 'Physics', 'Computer Science'],
    'average_grade': 73.5,
}

# Add 'passed' key
student['passed'] = student['average_grade'] >= 50
student['age']    = 21

print('Student Record:')
for key, value in student.items():
    if key != 'subjects':
        print(f'  {key:15s}: {value}')

print('  subjects       :')
for i, subject in enumerate(student['subjects'], start=1):
    print(f'    {i}. {subject}')
# → # Student Record:
# → #   name           : Alice Johnson
# → #   age            : 21
# → #   average_grade  : 73.5
# → #   passed         : True