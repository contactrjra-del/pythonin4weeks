"""
Python for Beginners — Week 2
Exercise 10: Contact Book with Search and Statistics
Difficulty: Challenging
Week theme: Collections and Loops — Lists, Dicts, Sets, Loops, Comprehensions

Part of the Python Mastery Series — Volume 1
"""
contacts = [
    {'name':'Alice Brown',   'phone':'07700900001','email':'alice@x.com', 'tags':{'work','friend'}},
    {'name':'Bob Smith',     'phone':'07700900002','email':'bob@x.com',   'tags':{'family'}},
    {'name':'Carol Jones',   'phone':'07700900003','email':'carol@x.com', 'tags':{'work'}},
    {'name':'Dave Wilson',   'phone':'07700900002','email':'dave@x.com',  'tags':{'friend'}},  # duplicate phone!
    {'name':'Eve Davis',     'phone':'07700900005','email':'eve@x.com',   'tags':{'work','family'}},
]

def display_contact(c):
    tags_str = ', '.join(sorted(c['tags']))
    print(f"  {c['name']:<18} {c['phone']}  {c['email']:<20}  [{tags_str}]")

def add_contact(contacts):
    name  = input('Name:  ').strip()
    phone = input('Phone: ').strip()
    email = input('Email: ').strip()
    tags_input = input('Tags (comma-separated): ')
    tags  = {t.strip().lower() for t in tags_input.split(',') if t.strip()}
    contacts.append({'name':name,'phone':phone,'email':email,'tags':tags})
    print(f'Contact "{name}" added.')

def search_by_name(contacts, query):
    q = query.lower()
    results = [c for c in contacts if q in c['name'].lower()]
    if results:
        print(f'  Found {len(results)} contact(s):')
        for c in results: display_contact(c)
    else:
        print(f'  No contacts matching "{query}".')

def contacts_by_tag(contacts, tag):
    tagged = [c for c in contacts if tag.lower() in c['tags']]
    print(f'  Contacts tagged "{tag}" ({len(tagged)}):')
    for c in tagged: display_contact(c)

def show_stats(contacts):
    # Flatten all tags from all contacts
    all_tags = [tag for c in contacts for tag in c['tags']]
    tag_counts = {}
    for tag in all_tags:
        tag_counts[tag] = tag_counts.get(tag, 0) + 1
    top_tag = max(tag_counts, key=tag_counts.get) if tag_counts else 'N/A'
    # Duplicate phone detection
    phone_count = {}
    for c in contacts:
        phone_count[c['phone']] = phone_count.get(c['phone'], 0) + 1
    dupes = {p for p, n in phone_count.items() if n > 1}
    print(f'  Total contacts:  {len(contacts)}')
    print(f'  Unique tags:     {sorted(set(all_tags))}')
    print(f'  Most common tag: {top_tag} ({tag_counts.get(top_tag,0)}×)')
    print(f'  Duplicate phones:{sorted(dupes) if dupes else "None"}')

while True:
    print('\n1)All  2)Add  3)Search  4)Tag  5)Stats  6)Quit')
    choice = input('> ').strip()
    if choice == '1':
        for c in sorted(contacts, key=lambda c: c['name']): display_contact(c)
    elif choice == '2': add_contact(contacts)
    elif choice == '3': search_by_name(contacts, input('Search name: '))
    elif choice == '4': contacts_by_tag(contacts, input('Tag to search: '))
    elif choice == '5': show_stats(contacts)
    elif choice == '6': print('Bye!'); break