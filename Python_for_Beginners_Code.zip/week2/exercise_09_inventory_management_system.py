"""
Python for Beginners — Week 2
Exercise 9: Inventory Management System
Difficulty: Challenging
Week theme: Collections and Loops — Lists, Dicts, Sets, Loops, Comprehensions

Part of the Python Mastery Series — Volume 1
"""
inventory = {
    'apple':  {'price': 0.45, 'quantity': 100, 'category': 'fresh'},
    'bread':  {'price': 1.20, 'quantity':   8, 'category': 'bakery'},
    'milk':   {'price': 0.89, 'quantity':   3, 'category': 'fresh'},
    'muffin': {'price': 0.75, 'quantity':  20, 'category': 'bakery'},
}

def show_stock(inv):
    print(f'\n  {'Product':<12} {'Price':>7} {'Qty':>5} {'Value':>8} {'Category':<10}')
    print('  ' + '─'*48)
    for product, data in sorted(inv.items()):
        val = data['price'] * data['quantity']
        print(f"  {product:<12} £{data['price']:>5.2f} {data['quantity']:>5} £{val:>6.2f} {data['category']}")

while True:
    print('\n1)View  2)Stock  3)Sell  4)LowStock  5)Categories  6)Quit')
    choice = input('Choose: ').strip()

    if choice == '1':
        show_stock(inventory)

    elif choice == '2':
        name = input('Product name: ').lower().strip()
        qty  = int(input('Quantity to add: '))
        if name in inventory:
            inventory[name]['quantity'] += qty
            print(f'Restocked {name}. New qty: {inventory[name]["quantity"]}')
        else:
            price    = float(input('Price: £'))
            category = input('Category: ').lower().strip()
            inventory[name] = {'price':price,'quantity':qty,'category':category}
            print(f'Added new product: {name}')

    elif choice == '3':
        name = input('Product name: ').lower().strip()
        if name not in inventory:
            print(f'Product {name!r} not found.')
        else:
            qty = int(input('Quantity to sell: '))
            if qty > inventory[name]['quantity']:
                print(f'Insufficient stock. Available: {inventory[name]["quantity"]}')
            else:
                inventory[name]['quantity'] -= qty
                revenue = inventory[name]['price'] * qty
                print(f'Sold {qty}×{name}. Revenue: £{revenue:.2f}')

    elif choice == '4':
        low = [(p, d['quantity']) for p, d in inventory.items() if d['quantity'] < 5]
        if low:
            print('⚠  LOW STOCK ALERT:')
            for p, q in low: print(f'  {p}: only {q} left')
        else:
            print('All stock levels OK.')

    elif choice == '5':
        cat_totals = {}
        for product, data in inventory.items():
            cat = data['category']
            value = data['price'] * data['quantity']
            cat_totals[cat] = cat_totals.get(cat, 0) + value
        print('\nCategory Totals:')
        for cat, total in sorted(cat_totals.items()): print(f'  {cat:<12}: £{total:,.2f}')

    elif choice == '6':
        print('Goodbye!'); break