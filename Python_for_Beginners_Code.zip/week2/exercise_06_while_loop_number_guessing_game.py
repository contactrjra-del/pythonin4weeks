"""
Python for Beginners — Week 2
Exercise 6: While Loop — Number Guessing Game
Difficulty: Medium
Week theme: Collections and Loops — Lists, Dicts, Sets, Loops, Comprehensions

Part of the Python Mastery Series — Volume 1
"""
import random

secret    = random.randint(1, 100)
max_tries = 7
attempts  = 0
guesses   = []
won       = False

print(f'\nGuess the number (1–100). You have {max_tries} attempts.')

while attempts < max_tries:
    remaining = max_tries - attempts
    raw       = input(f'  Attempt {attempts+1}/{max_tries} — your guess: ')

    if not raw.isdigit():
        print('  Please enter a whole number.')
        continue   # don't count invalid input as an attempt

    guess = int(raw)
    guesses.append(guess)
    attempts += 1

    if guess == secret:
        print(f'  🎉 Correct! You guessed {secret} in {attempts} attempt(s).')
        won = True
        break
    elif guess < secret:
        print(f'  📈 Too low!  Try higher.  ({remaining-1} attempts left)')
    else:
        print(f'  📉 Too high! Try lower.  ({remaining-1} attempts left)')

if not won:
    print(f'  ❌ Out of attempts. The number was {secret}.')

print(f'\nYour guesses: {guesses}')