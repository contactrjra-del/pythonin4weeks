Week 2 — Collections and Loops — Lists, Dicts, Sets, Loops, Comprehensions
============================================================

Topics covered this week:
  • Lists and slicing
  • Tuples and dictionaries
  • Sets
  • For and while loops
  • List comprehensions

Files in this folder:
----------------------------------------
  exercise_01_list_basics_five_operations.py  — List Basics — Five Operations [Easy]
  exercise_02_dictionary_student_record.py  — Dictionary — Student Record [Easy]
  exercise_03_set_operations_mailing_list_deduplication.py  — Set Operations — Mailing List Deduplication [Easy]
  exercise_04_for_loop_times_table_generator.py  — For Loop — Times Table Generator [Medium]
  exercise_05_dictionary_word_frequency_counter.py  — Dictionary — Word Frequency Counter [Medium]
  exercise_06_while_loop_number_guessing_game.py  — While Loop — Number Guessing Game [Medium]
  exercise_07_list_comprehension_data_transformation.py  — List Comprehension — Data Transformation [Medium]
  exercise_08_nested_collections_class_results_processor.py  — Nested Collections — Class Results Processor [Challenging]
  exercise_09_inventory_management_system.py  — Inventory Management System [Challenging]
  exercise_10_contact_book_with_search_and_statistics.py  — Contact Book with Search and Statistics [Challenging]
  project_01_student_grade_report_generator.py       — Student Grade Report Generator
  project_02_supermarket_self_checkout_system.py       — Supermarket Self-Checkout System