"""
Python for Beginners — Week 2
Mini-Project 1: Student Grade Report Generator
Week theme: Collections and Loops — Lists, Dicts, Sets, Loops, Comprehensions

This is a capstone project combining all Week 2 concepts.
Run with:  python project_01_student_grade_report_generator.py

Part of the Python Mastery Series — Volume 1
"""
# ══════════════════════════════════════════════════════
# PROJECT 1: Student Grade Report Generator
# Collections used: list of dicts, lists, comprehensions
# ══════════════════════════════════════════════════════
GRADE_THRESHOLDS = [('A',90),('B',75),('C',60),('D',50),('F',0)]
SUBJECTS = ['Maths', 'English', 'Science']

students_raw = [
    {'name':'Alice',  'year':11,'scores':[88, 92, 79]},
    {'name':'Bob',    'year':11,'scores':[65, 58, 71]},
    {'name':'Carol',  'year':12,'scores':[95, 98, 92]},
    {'name':'Dave',   'year':11,'scores':[42, 55, 48]},
    {'name':'Eve',    'year':12,'scores':[78, 84, 90]},
    {'name':'Frank',  'year':12,'scores':[55, 60, 63]},
]

def get_grade(avg):
    for label, threshold in GRADE_THRESHOLDS:
        if avg >= threshold:
            return label
    return 'F'

# ── Enrich student records ───────────────────────────────
students = []
for s in students_raw:
    total   = sum(s['scores'])
    average = round(total / len(s['scores']), 1)
    students.append({
        'name':    s['name'],
        'year':    s['year'],
        'scores':  s['scores'],
        'total':   total,
        'average': average,
        'grade':   get_grade(average),
    })

# Assign ranks by sorting descending, then attaching rank 1, 2, 3...
ranked = sorted(students, key=lambda s: s['average'], reverse=True)
for i, s in enumerate(ranked, start=1):
    s['rank'] = i

# ── Individual results table ─────────────────────────────
print('='*70)
print(f"{'STUDENT GRADE REPORT':^70}")
print('='*70)
header = f"{'Name':<8} {'Yr':>3} {'Maths':>6} {'English':>8} {'Science':>8} {'Avg':>5} {'Grd':>4} {'Rank':>5}"
print(header)
print('─'*70)
for s in sorted(students, key=lambda s: s['name']):
    sc = s['scores']
    print(f"{s['name']:<8} {s['year']:>3} {sc[0]:>6} {sc[1]:>8} {sc[2]:>8} {s['average']:>5} {s['grade']:>4} {s['rank']:>5}")

# ── Class statistics ─────────────────────────────────────
all_avgs   = [s['average'] for s in students]
class_avg  = round(sum(all_avgs) / len(all_avgs), 1)
pass_count = sum(1 for s in students if s['average'] >= 50)
pass_rate  = pass_count / len(students) * 100
top        = ranked[0]
bottom     = ranked[-1]
print('\n' + '─'*70)
print('CLASS STATISTICS')
print(f'  Class average:  {class_avg}')
print(f'  Pass rate:      {pass_rate:.0f}% ({pass_count}/{len(students)} students)')
print(f"  Top student:    {top['name']} ({top['average']})")
print(f"  Lowest average: {bottom['name']} ({bottom['average']})")

# ── Per-subject statistics ───────────────────────────────
print('\nSUBJECT BREAKDOWN')
for i, subj in enumerate(SUBJECTS):
    subj_scores = [s['scores'][i] for s in students]
    subj_avg    = round(sum(subj_scores) / len(subj_scores), 1)
    best = max(students, key=lambda s: s['scores'][i])
    worst= min(students, key=lambda s: s['scores'][i])
    print(f"  {subj:<10}: avg={subj_avg:>5}, high={max(subj_scores)} ({best['name']}), low={min(subj_scores)} ({worst['name']})")

# ── At-risk students ─────────────────────────────────────
at_risk = [s for s in students if s['average'] < 60]
if at_risk:
    print('\nAT-RISK STUDENTS (average < 60):')
    for s in at_risk:
        print(f"  ⚠  {s['name']} — average {s['average']} (Grade {s['grade']})")
        failed_subjs = [SUBJECTS[i] for i,sc in enumerate(s['scores']) if sc < 50]
        if failed_subjs: print(f"      Failed individual subjects: {', '.join(failed_subjs)}")

# ── Leaderboard ──────────────────────────────────────────
print('\nLEADERBOARD')
for s in ranked:
    bar = '█' * int(s['average'] // 5)
    print(f"  #{s['rank']}  {s['name']:<8} {s['average']:>5}  {bar}")
# → # #1  Carol     95.0  ███████████████████
# → # #2  Eve       84.0  ████████████████
# → # #3  Alice     86.3  █████████████████
