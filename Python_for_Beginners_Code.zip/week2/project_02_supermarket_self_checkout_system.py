"""
Python for Beginners — Week 2
Mini-Project 2: Supermarket Self-Checkout System
Week theme: Collections and Loops — Lists, Dicts, Sets, Loops, Comprehensions

This is a capstone project combining all Week 2 concepts.
Run with:  python project_02_supermarket_self_checkout_system.py

Part of the Python Mastery Series — Volume 1
"""
# ══════════════════════════════════════════════════════
# PROJECT 2: Supermarket Self-Checkout System
# Collections: dict (catalogue), list of dicts (basket),
#              set (scanned barcodes), dict comprehensions
# ══════════════════════════════════════════════════════
from datetime import datetime

CATALOGUE = {
    '5000077000501': {'name':'Whole Milk 2L',  'price':1.39, 'category':'Dairy'},
    '5000077011111': {'name':'Cheddar 400g',   'price':3.50, 'category':'Dairy'},
    '5000077022222': {'name':'Sourdough Loaf', 'price':2.20, 'category':'Bakery'},
    '5000077033333': {'name':'Croissants x4',  'price':1.75, 'category':'Bakery'},
    '5000077044444': {'name':'Chicken Breast', 'price':5.00, 'category':'Meat'},
    '5000077055555': {'name':'Salmon Fillet',  'price':4.50, 'category':'Meat'},
    '5000077066666': {'name':'Bananas 1kg',    'price':0.89, 'category':'Produce'},
    '5000077077777': {'name':'Broccoli',       'price':0.65, 'category':'Produce'},
}
VAT_RATE      = 0.20
DISCOUNT_THRESHOLD = 30.00
DISCOUNT_RATE      = 0.10
BULK_SCAN_LIMIT    = 3

basket        = []   # list of {barcode, name, quantity, unit_price}
scan_counts   = {}   # {barcode: total_times_scanned}
bulk_flagged  = set()

# ── Scanning loop ───────────────────────────────────────
print('\n' + '='*45)
print(f"{'SELF-CHECKOUT':^45}")
print('='*45)
print("Type barcode + quantity. Type 'done' to finish.")

while True:
    barcode = input('\nBarcode: ').strip()
    if barcode.lower() == 'done':
        break
    if barcode not in CATALOGUE:
        print(f'  ❌ Barcode {barcode!r} not recognised.')
        continue
    qty_str = input('  Quantity: ').strip()
    if not qty_str.isdigit() or int(qty_str) < 1:
        print('  Quantity must be a positive whole number.')
        continue
    quantity = int(qty_str)
    product  = CATALOGUE[barcode]
    # Track scan count
    scan_counts[barcode] = scan_counts.get(barcode, 0) + 1
    if scan_counts[barcode] > BULK_SCAN_LIMIT and barcode not in bulk_flagged:
        print(f"  ⚠  Bulk purchase flag: {product['name']} scanned {scan_counts[barcode]}× this session.")
        bulk_flagged.add(barcode)
    # Add to basket or update existing entry
    existing = next((item for item in basket if item['barcode'] == barcode), None)
    if existing:
        existing['quantity'] += quantity
        print(f"  Updated {product['name']}: now {existing['quantity']} in basket")
    else:
        basket.append({'barcode':barcode,'name':product['name'],'quantity':quantity,'unit_price':product['price'],'category':product['category']})
        print(f"  Added: {product['name']} × {quantity}  =  £{product['price']*quantity:.2f}")

if not basket:
    print('No items scanned. Goodbye!'); exit()

# ── Calculation ─────────────────────────────────────────
for item in basket:
    item['subtotal'] = round(item['unit_price'] * item['quantity'], 2)

gross     = sum(item['subtotal'] for item in basket)
discount  = gross * DISCOUNT_RATE if gross > DISCOUNT_THRESHOLD else 0
pre_vat   = gross - discount
vat_amount= round(pre_vat * VAT_RATE, 2)
total     = round(pre_vat + vat_amount, 2)

# Category totals
cat_totals = {}
for item in basket:
    cat = item['category']
    cat_totals[cat] = cat_totals.get(cat, 0) + item['subtotal']

# ── Receipt ─────────────────────────────────────────────
now = datetime.now().strftime('%d/%m/%Y %H:%M')
print('\n' + '='*45)
print(f"{'SMART MART SUPERMARKET':^45}")
print(f"{'Receipt':^45}")
print(f"  {now}")
print('─'*45)
for item in basket:
    print(f"  {item['name']:<22} x{item['quantity']:<3} £{item['subtotal']:>6.2f}")
print('─'*45)
print(f"  {'Subtotal':<30} £{gross:>6.2f}")
if discount:
    print(f"  {'Loyalty Discount (10%)':<30} -£{discount:>5.2f}")
print(f"  {'VAT (20%)':<30} £{vat_amount:>6.2f}")
print('='*45)
print(f"  {'TOTAL':<30} £{total:>6.2f}")
print('='*45)
print('  Category Breakdown:')
for cat, amount in sorted(cat_totals.items()):
    print(f"    {cat:<12}: £{amount:>6.2f}")
print('='*45)
print('  Thank you for shopping with Smart Mart!')
