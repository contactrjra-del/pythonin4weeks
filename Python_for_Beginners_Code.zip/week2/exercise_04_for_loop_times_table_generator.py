"""
Python for Beginners — Week 2
Exercise 4: For Loop — Times Table Generator
Difficulty: Medium
Week theme: Collections and Loops — Lists, Dicts, Sets, Loops, Comprehensions

Part of the Python Mastery Series — Volume 1
"""
n = int(input('Enter a number (1-12): '))

products = []
first_over_50 = None

print(f'\n  Multiplication Table for {n}')
print('  ' + '─'*28)
for multiplier in range(1, 13):
    product = n * multiplier
    products.append(product)
    print(f'  {multiplier:2d} × {n:2d} = {product:4d}')
    if first_over_50 is None and product > 50:
        first_over_50 = multiplier

print('  ' + '─'*28)
print(f'  Sum of products:     {sum(products)}')
print(f'  Largest product:     {max(products)}')
if first_over_50:
    print(f'  First product > 50:  {n} × {first_over_50} = {n * first_over_50}')
else:
    print(f'  No product exceeds 50 in this table.')