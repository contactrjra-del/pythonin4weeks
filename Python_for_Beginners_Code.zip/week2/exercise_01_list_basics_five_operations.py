"""
Python for Beginners — Week 2
Exercise 1: List Basics — Five Operations
Difficulty: Easy
Week theme: Collections and Loops — Lists, Dicts, Sets, Loops, Comprehensions

Part of the Python Mastery Series — Volume 1
"""
fruits = ['apple', 'banana', 'cherry', 'grape', 'kiwi', 'pear']

fruits.append('mango')          # add to end
fruits.insert(2, 'strawberry')  # insert at position 2
fruits.remove('apple')          # remove first occurrence
fruits.sort()                   # sort alphabetically in place

print(f'List:   {fruits}')
print(f'Count:  {len(fruits)}')
print(f'Last:   {fruits[-1]}')
# → # List:   ['banana', 'cherry', 'grape', 'kiwi', 'mango', 'pear', 'strawberry']
# → # Count:  7
# → # Last:   strawberry