"""
Python for Beginners — Week 2
Exercise 7: List Comprehension — Data Transformation
Difficulty: Medium
Week theme: Collections and Loops — Lists, Dicts, Sets, Loops, Comprehensions

Part of the Python Mastery Series — Volume 1
"""
records = ['Alice,Engineering,75000','Bob,Marketing,52000',
           'Carol,Engineering,88000','Dave,HR,48000',
           'Eve,Engineering,92000','Frank,Marketing,61000']

# (a) Parse to list of dicts
employees = [
    {'name': r.split(',')[0], 'department': r.split(',')[1], 'salary': int(r.split(',')[2])}
    for r in records
]

# (b) Engineering staff as {name: salary}
engineering = {e['name']: e['salary'] for e in employees if e['department'] == 'Engineering'}

# (c) Average Engineering salary
avg_eng = sum(engineering.values()) / len(engineering) if engineering else 0

# (d) All employees sorted by salary descending
by_salary = [e['name'] for e in sorted(employees, key=lambda e: e['salary'], reverse=True)]

print('All employees:', employees)
print('Engineering:  ', engineering)
print(f'Avg Eng salary: £{avg_eng:,.0f}')
print('By salary:     ', by_salary)
# → # Engineering:   {'Alice': 75000, 'Carol': 88000, 'Eve': 92000}
# → # Avg Eng salary: £85,000
# → # By salary:      ['Eve', 'Carol', 'Alice', 'Frank', 'Bob', 'Dave']