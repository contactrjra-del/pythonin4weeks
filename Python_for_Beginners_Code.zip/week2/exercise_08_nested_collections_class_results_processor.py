"""
Python for Beginners — Week 2
Exercise 8: Nested Collections — Class Results Processor
Difficulty: Challenging
Week theme: Collections and Loops — Lists, Dicts, Sets, Loops, Comprehensions

Part of the Python Mastery Series — Volume 1
"""
students = [
    {'name': 'Alice', 'scores': [88, 92, 79]},
    {'name': 'Bob',   'scores': [65, 58, 71]},
    {'name': 'Carol', 'scores': [95, 98, 92]},
    {'name': 'Dave',  'scores': [42, 55, 48]},
    {'name': 'Eve',   'scores': [78, 84, 90]},
]
subjects = ['Maths', 'English', 'Science']

def get_grade(avg):
    if avg >= 90: return 'A'
    if avg >= 75: return 'B'
    if avg >= 60: return 'C'
    if avg >= 50: return 'D'
    return 'F'

# Enrich each student dict
for student in students:
    avg = sum(student['scores']) / len(student['scores'])
    student['average'] = round(avg, 1)
    student['grade']   = get_grade(avg)

# Print individual results
print(f'{'Name':<10} {'Maths':>7} {'English':>8} {'Science':>8} {'Avg':>6} {'Grade':>6}')
print('─'*52)
for s in students:
    print(f"{s['name']:<10} {s['scores'][0]:>7} {s['scores'][1]:>8} {s['scores'][2]:>8} {s['average']:>6} {s['grade']:>6}")

# Subject averages
print('\nSubject Averages:')
for i, subj in enumerate(subjects):
    subj_avg = sum(s['scores'][i] for s in students) / len(students)
    print(f'  {subj:<10}: {subj_avg:.1f}')

# Top student
top = max(students, key=lambda s: s['average'])
print(f"\nTop student: {top['name']} ({top['average']})")

# Failed any subject
print('\nStudents who failed at least one subject:')
for s in students:
    failed_subjects = [subjects[i] for i, sc in enumerate(s['scores']) if sc < 50]
    if failed_subjects:
        print(f"  {s['name']}: failed {failed_subjects}")

# Bar chart
print('\nAverage Bar Chart:')
for s in sorted(students, key=lambda s: s['average'], reverse=True):
    bar = '█' * int(s['average'] // 5)
    print(f"  {s['name']:<8} {s['average']:5.1f} {bar}")
# → # Carol     95.0 ███████████████████
# → # Top student: Carol (95.0)