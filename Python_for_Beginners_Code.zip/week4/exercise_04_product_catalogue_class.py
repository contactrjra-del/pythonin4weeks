"""
Python for Beginners — Week 4
Exercise 4: Product Catalogue Class
Difficulty: Medium
Week theme: Modules, OOP, Classes and Standard Library

Part of the Python Mastery Series — Volume 1
"""
class Product:
    def __init__(self, name, sku, price, quantity, category):
        self.name     = name
        self.sku      = sku.upper()
        self.category = category
        self._price   = 0.0; self.price = price        # triggers setter
        self._qty     = 0;   self.quantity = quantity  # triggers setter

    @property
    def price(self):         return self._price
    @price.setter
    def price(self, value):
        if value < 0: raise ValueError(f'Price cannot be negative: {value}')
        self._price = round(float(value), 2)

    @property
    def quantity(self):       return self._qty
    @quantity.setter
    def quantity(self, value):
        if value < 0: raise ValueError(f'Quantity cannot be negative: {value}')
        self._qty = int(value)

    @property
    def total_value(self):   return round(self._price * self._qty, 2)
    @property
    def is_in_stock(self):   return self._qty > 0
    @property
    def is_low_stock(self):  return 0 < self._qty < 5

    def apply_discount(self, percent):
        if not 0 <= percent <= 100:
            raise ValueError(f'Discount must be 0–100%, got {percent}%')
        self.price = self._price * (1 - percent / 100)
        print(f'  {self.name}: price now £{self._price:.2f} ({percent}% off)')

    def restock(self, qty):
        if qty <= 0: raise ValueError('Restock quantity must be positive')
        self._qty += qty
        print(f'  Restocked {self.name}: +{qty} → {self._qty} in stock')

    def sell(self, qty):
        if qty <= 0: raise ValueError('Sell quantity must be positive')
        if qty > self._qty:
            raise ValueError(f'Only {self._qty} of {self.name} in stock')
        self._qty -= qty
        return qty * self._price

    def __str__(self):
        low = ' ⚠ LOW' if self.is_low_stock else ''
        return f'[{self.sku}] {self.name:<20} £{self._price:>7.2f}  qty:{self._qty:>4}{low}'
    def __repr__(self):
        return f'Product({self.name!r}, {self.sku!r}, {self._price}, {self._qty})'

class Catalogue:
    def __init__(self): self._products = []

    def add_product(self, product):
        self._products.append(product)
        print(f'Added: {product.name} ({product.sku})')

    def find_by_sku(self, sku):
        return next((p for p in self._products if p.sku == sku.upper()), None)

    def find_by_category(self, category):
        return [p for p in self._products if p.category.lower() == category.lower()]

    @property
    def total_stock_value(self):
        return sum(p.total_value for p in self._products)

    def low_stock_report(self):
        low = [p for p in self._products if p.is_low_stock]
        if not low: print('All stock levels OK.'); return
        print(f'LOW STOCK REPORT ({len(low)} products):')
        for p in low: print(f'  {p}')

    def apply_category_discount(self, category, percent):
        prods = self.find_by_category(category)
        print(f'Applying {percent}% discount to {category} ({len(prods)} products):')
        for p in prods: p.apply_discount(percent)

    def __str__(self):
        lines = [f'=== CATALOGUE ({len(self._products)} products) ===']
        lines += [str(p) for p in self._products]
        lines.append(f'Total stock value: £{self.total_stock_value:,.2f}')
        return '\n'.join(lines)

# Demo:
cat = Catalogue()
cat.add_product(Product('Laptop', 'LAP001', 999.99, 15, 'Electronics'))
cat.add_product(Product('Mouse',  'MOU001', 24.99,  3,  'Electronics'))
cat.add_product(Product('Desk',   'DSK001', 299.00, 8,  'Furniture'))
print(cat)
cat.apply_category_discount('Electronics', 10)
cat.low_stock_report()