"""
Python for Beginners — Week 4
Exercise 1: Dice Roller Simulator
Difficulty: Easy
Week theme: Modules, OOP, Classes and Standard Library

Part of the Python Mastery Series — Volume 1
"""
import random

def roll_dice(num_dice, sides=6):
    '''Roll num_dice dice with given sides. Returns (results, total).'''
    if num_dice < 1:
        raise ValueError(f'num_dice must be >= 1, got {num_dice}')
    if sides < 1:
        raise ValueError(f'sides must be >= 1, got {sides}')
    results = [random.randint(1, sides) for _ in range(num_dice)]
    total   = sum(results)
    print(f'Rolling {num_dice}d{sides}: {results} → Total: {total}')
    return results, total

def run_simulation(num_dice, sides, num_rolls):
    '''Simulate num_rolls dice rolls and return the average total.'''
    all_totals = []
    for _ in range(num_rolls):
        _, total = roll_dice(num_dice, sides)
        all_totals.append(total)
    avg = sum(all_totals) / len(all_totals)
    print(f'\nSimulation: {num_rolls} rolls of {num_dice}d{sides}')
    print(f'Average total: {avg:.2f}  (expected: {num_dice * (sides+1)/2:.2f})')
    return avg

# Test:
roll_dice(3)           # 3 standard d6 dice
roll_dice(2, sides=20) # 2 twenty-sided dice
run_simulation(2, 6, 10000)  # law of large numbers
# → # Average total: 6.99  (expected: 7.00)