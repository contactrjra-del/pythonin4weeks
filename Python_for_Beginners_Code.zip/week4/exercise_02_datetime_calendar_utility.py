"""
Python for Beginners — Week 4
Exercise 2: datetime Calendar Utility
Difficulty: Easy
Week theme: Modules, OOP, Classes and Standard Library

Part of the Python Mastery Series — Volume 1
"""
from datetime import datetime, date
import calendar

def get_date_info(date_str):
    '''Return detailed information about a date string (YYYY-MM-DD).'''
    try:
        d = datetime.strptime(date_str, '%Y-%m-%d').date()
    except ValueError as e:
        return {'error': f'Invalid date: {e}'}

    # Days until year end
    year_end    = date(d.year, 12, 31)
    days_left   = (year_end - d).days
    days_in_month = calendar.monthrange(d.year, d.month)[1]

    return {
        'date':              d.strftime('%d %B %Y'),
        'day_of_week':       d.strftime('%A'),
        'day_number':        d.timetuple().tm_yday,   # 1–366
        'week_number':       d.isocalendar()[1],
        'is_leap_year':      calendar.isleap(d.year),
        'days_in_month':     days_in_month,
        'days_until_year_end': days_left,
    }

# Tests
for ds in ['2024-03-15', '2000-02-29', '1900-02-29']:
    info = get_date_info(ds)
    print(f'\nDate: {ds}')
    for k, v in info.items(): print(f'  {k:<22}: {v}')
# → # Date: 1900-02-29
# → #   error                 : Invalid date: day is out of range for month