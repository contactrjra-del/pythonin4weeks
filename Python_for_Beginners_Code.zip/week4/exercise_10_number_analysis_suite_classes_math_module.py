"""
Python for Beginners — Week 4
Exercise 10: Number Analysis Suite — Classes + math Module
Difficulty: Challenging
Week theme: Modules, OOP, Classes and Standard Library

Part of the Python Mastery Series — Volume 1
"""
import math

class NumberAnalyser:
    '''Analyse a dataset of integers with number theory tools.'''
    def __init__(self, data):
        self._data = [int(x) for x in data]

    @staticmethod
    def is_prime(n):
        if n < 2: return False
        if n == 2: return True
        if n % 2 == 0: return False
        for i in range(3, math.isqrt(n)+1, 2):
            if n % i == 0: return False
        return True

    @staticmethod
    def prime_factors(n):
        factors, d = [], 2
        while d * d <= n:
            while n % d == 0:
                factors.append(d); n //= d
            d += 1
        if n > 1: factors.append(n)
        return factors

    @staticmethod
    def is_perfect(n):
        if n < 2: return False
        divisors = [i for i in range(1, n) if n % i == 0]
        return sum(divisors) == n

    @staticmethod
    def digital_root(n):
        n = abs(n)
        while n >= 10:
            n = sum(int(d) for d in str(n))
        return n

    @staticmethod
    def nearest_primes(n):
        below = n - 1
        while below > 1 and not NumberAnalyser.is_prime(below): below -= 1
        above = n + 1
        while not NumberAnalyser.is_prime(above): above += 1
        return (below if below > 1 else None, above)

    def analyse(self, n):
        n = int(n)
        prev_prime, next_prime = self.nearest_primes(n)
        return {
            'number':         n,
            'is_prime':       self.is_prime(n),
            'is_perfect':     self.is_perfect(n),
            'is_even':        n % 2 == 0,
            'prime_factors':  self.prime_factors(n),
            'digital_root':   self.digital_root(n),
            'sqrt':           round(math.sqrt(n), 4) if n >= 0 else None,
            'factorial':      math.factorial(n) if 0 <= n <= 20 else 'too large',
            'nearest_primes': (prev_prime, next_prime),
        }

    def analyse_dataset(self):
        primes   = [n for n in self._data if self.is_prime(n)]
        perfects = [n for n in self._data if self.is_perfect(n)]
        evens    = [n for n in self._data if n % 2 == 0]
        print(f'\n=== NUMBER ANALYSIS REPORT ===')
        print(f'Dataset:   {self._data}')
        print(f'Count:     {len(self._data)}')
        print(f'Sum:       {sum(self._data)}')
        print(f'Mean:      {sum(self._data)/len(self._data):.2f}')
        print(f'Primes:    {primes}')
        print(f'Perfects:  {perfects}  (6=1+2+3, 28=1+2+4+7+14)')
        print(f'Evens:     {len(evens)}/{len(self._data)}')
        print(f'Max:       {max(self._data)}, Min: {min(self._data)}')
        print('\nIndividual analysis:')
        for n in self._data:
            a = self.analyse(n)
            flags = []
            if a['is_prime']:   flags.append('PRIME')
            if a['is_perfect']: flags.append('PERFECT')
            if not a['is_even']: flags.append('ODD')
            print(f"  {n:5d}  factors:{a['prime_factors']}  root:{a['digital_root']}  {' '.join(flags)}")

# Demo:
na = NumberAnalyser([1, 2, 6, 7, 12, 13, 17, 28, 30, 37, 100])
na.analyse_dataset()
# → # Primes:    [2, 7, 13, 17, 37]
# → # Perfects:  [6, 28]