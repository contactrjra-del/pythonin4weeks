"""
Python for Beginners — Week 4
Exercise 5: Statistics Library Using math Module
Difficulty: Medium
Week theme: Modules, OOP, Classes and Standard Library

Part of the Python Mastery Series — Volume 1
"""
import math

class Stats:
    '''Statistical analysis of a numeric dataset.'''
    def __init__(self, data):
        if not data:
            raise ValueError('Dataset cannot be empty')
        self._data   = list(data)
        self._sorted = sorted(self._data)
        self._n      = len(self._data)

    def mean(self):
        return sum(self._data) / self._n

    def median(self):
        mid = self._n // 2
        if self._n % 2 == 1:
            return float(self._sorted[mid])
        return (self._sorted[mid-1] + self._sorted[mid]) / 2

    def mode(self):
        freq = {}
        for x in self._data: freq[x] = freq.get(x, 0) + 1
        max_count = max(freq.values())
        return sorted(k for k, v in freq.items() if v == max_count)

    def variance(self):
        m = self.mean()
        return sum((x - m) ** 2 for x in self._data) / self._n

    def std_dev(self):
        return math.sqrt(self.variance())

    def min_val(self):   return self._sorted[0]
    def max_val(self):   return self._sorted[-1]
    def range_val(self): return self._sorted[-1] - self._sorted[0]

    def percentile(self, p):
        if not 0 <= p <= 100:
            raise ValueError(f'Percentile must be 0–100, got {p}')
        idx = (p / 100) * (self._n - 1)     # floating point index
        low = math.floor(idx)
        high = math.ceil(idx)
        if low == high: return float(self._sorted[int(idx)])
        frac = idx - low
        return self._sorted[low] + frac * (self._sorted[high] - self._sorted[low])

    def summarise(self):
        print(f'  n          : {self._n}')
        print(f'  Mean       : {self.mean():.3f}')
        print(f'  Median     : {self.median():.3f}')
        print(f'  Mode       : {self.mode()}')
        print(f'  Std Dev    : {self.std_dev():.3f}')
        print(f'  Min / Max  : {self.min_val()} / {self.max_val()}')
        print(f'  Range      : {self.range_val()}')
        print(f'  25th pct   : {self.percentile(25):.3f}')
        print(f'  75th pct   : {self.percentile(75):.3f}')

scores = [85, 92, 78, 95, 88, 92, 70, 85, 92, 76, 88, 91]
s = Stats(scores)
s.summarise()
# → # Mean: 86.000  Std Dev: 6.858  Mode: [92]