"""
Python for Beginners — Week 4
Mini-Project 1: Personal Expense Tracker — OOP & File-Backed
Week theme: Modules, OOP, Classes and Standard Library

This is a capstone project combining all Week 4 concepts.
Run with:  python project_01_personal_expense_tracker_oop_file_backed.py

Part of the Python Mastery Series — Volume 1
"""
'''Expense Tracker — Week 4 Capstone Project'''
import csv, math
from datetime import date, datetime
from pathlib import Path

FILEPATH = Path('expenses.csv')

class Category:
    def __init__(self, name, monthly_budget=0.0):
        self.name           = name.strip().title()
        self.monthly_budget = float(monthly_budget)
    def __str__(self): return f'{self.name} (budget £{self.monthly_budget:.2f}/month)'

class Expense:
    def __init__(self, amount, category, description, expense_date=None):
        if float(amount) <= 0: raise ValueError('Amount must be positive')
        self.amount      = round(float(amount), 2)
        self.category    = category.strip().title()
        self.description = description.strip()
        if expense_date is None:
            self.date = date.today()
        elif isinstance(expense_date, str):
            self.date = datetime.strptime(expense_date, '%Y-%m-%d').date()
        else:
            self.date = expense_date

    @property
    def month_key(self): return self.date.strftime('%Y-%m')
    def __str__(self):
        return f'{self.date}  {self.category:<15}  £{self.amount:>8.2f}  {self.description}'

class ExpenseTracker:
    DEFAULT_CATEGORIES = {'Food':400,'Transport':150,'Utilities':120,'Entertainment':100,'Healthcare':80,'Other':200}

    def __init__(self):
        self._expenses   = []
        self._categories = {
            name: Category(name, budget)
            for name, budget in self.DEFAULT_CATEGORIES.items()
        }

    def add_expense(self, amount, category, description, expense_date=None):
        if category.title() not in self._categories:
            print(f'  Note: new category {category!r} added automatically')
            self._categories[category.title()] = Category(category)
        e = Expense(amount, category, description, expense_date)
        self._expenses.append(e)
        print(f'  ✅ Added: {e}')
        return e

    def add_category(self, name, budget):
        self._categories[name.title()] = Category(name, budget)
        print(f'  Category added: {name} (budget £{budget}/month)')

    def save_to_csv(self, filepath=FILEPATH):
        with open(filepath, 'w', encoding='utf-8', newline='') as f:
            w = csv.DictWriter(f, fieldnames=['date','category','description','amount'])
            w.writeheader()
            for e in self._expenses:
                w.writerow({'date':e.date.isoformat(),'category':e.category,'description':e.description,'amount':e.amount})
        print(f'  Saved {len(self._expenses)} expenses to {filepath}')

    def load_from_csv(self, filepath=FILEPATH):
        if not Path(filepath).exists(): return 0
        self._expenses = []
        loaded = 0
        with open(filepath, 'r', encoding='utf-8', newline='') as f:
            for row in csv.DictReader(f):
                try:
                    self._expenses.append(Expense(row['amount'],row['category'],row['description'],row['date']))
                    loaded += 1
                except Exception as e: print(f'  Skipped bad row: {e}')
        print(f'  Loaded {loaded} expenses from {filepath}')
        return loaded

    def _get_month_expenses(self, year, month):
        target = f'{year}-{month:02d}'
        return [e for e in self._expenses if e.month_key == target]

    def monthly_summary(self, year=None, month=None):
        today = date.today()
        year  = year  or today.year
        month = month or today.month
        monthly = self._get_month_expenses(year, month)
        if not monthly: print(f'  No expenses for {year}-{month:02d}'); return
        cat_totals = {}
        for e in monthly: cat_totals[e.category] = cat_totals.get(e.category, 0) + e.amount
        grand = sum(cat_totals.values())
        largest = max(monthly, key=lambda e: e.amount)
        print(f'\n=== {year}-{month:02d} Monthly Summary ===')
        for e in sorted(monthly, key=lambda e: e.date): print(f'  {e}')
        print('  ' + '─'*55)
        for cat, total in sorted(cat_totals.items(), key=lambda x: -x[1]):
            budget = self._categories.get(cat, Category(cat)).monthly_budget
            status = '❌ OVER' if budget and total > budget else '✅'
            print(f'  {cat:<16}: £{total:>8.2f}  {status}')
        print(f'  TOTAL            : £{grand:>8.2f}')
        print(f'  Largest expense  : £{largest.amount:.2f} — {largest.description}')

    def budget_status(self):
        today  = date.today()
        target = today.strftime('%Y-%m')
        monthly = self._get_month_expenses(today.year, today.month)
        cat_spent = {}
        for e in monthly: cat_spent[e.category] = cat_spent.get(e.category,0) + e.amount
        print(f'\n=== Budget Status: {target} ===')
        print(f"{'Category':<16} {'Spent':>8} {'Budget':>8} {'Left':>8} {'Bar':<20}")
        print('─'*64)
        for name, cat in sorted(self._categories.items()):
            spent  = cat_spent.get(name, 0)
            budget = cat.monthly_budget
            left   = budget - spent
            pct    = min(spent/budget, 1.0) if budget > 0 else 0
            filled = int(pct * 20)
            bar    = '█' * filled + '░' * (20 - filled)
            status = '❌' if spent > budget > 0 else ''
            print(f'{name:<16} £{spent:>7.2f} £{budget:>7.2f} £{left:>+7.2f} {bar} {status}')

    def search(self, keyword):
        kw = keyword.lower()
        results = [e for e in self._expenses if kw in e.description.lower() or kw in e.category.lower()]
        print(f'  Found {len(results)} results for {keyword!r}:')
        for e in results: print(f'  {e}')
        return results

# ── Main menu ─────────────────────────────────────────────────────────────
def main():
    tracker = ExpenseTracker()
    tracker.load_from_csv()
    while True:
        print('\n1)Add  2)Monthly  3)Budget  4)Search  5)AddCategory  6)Save  7)Quit')
        c = input('> ').strip()
        if c == '1':
            try:
                amt  = float(input('  Amount £: '))
                cat  = input('  Category: ')
                desc = input('  Description: ')
                date_str = input('  Date (YYYY-MM-DD, or Enter for today): ').strip()
                tracker.add_expense(amt, cat, desc, date_str or None)
            except ValueError as e: print(f'  Error: {e}')
        elif c == '2':
            today = date.today()
            yr_s  = input(f'  Year [{today.year}]: ').strip() or str(today.year)
            mo_s  = input(f'  Month [{today.month}]: ').strip() or str(today.month)
            tracker.monthly_summary(int(yr_s), int(mo_s))
        elif c == '3': tracker.budget_status()
        elif c == '4': tracker.search(input('  Keyword: '))
        elif c == '5':
            name   = input('  Category name: ')
            budget = float(input('  Monthly budget £: '))
            tracker.add_category(name, budget)
        elif c == '6': tracker.save_to_csv()
        elif c == '7': tracker.save_to_csv(); print('Saved. Goodbye!'); break

if __name__ == '__main__':
    main()
