"""
Python for Beginners — Week 4
Exercise 7: Random Quiz Generator
Difficulty: Medium
Week theme: Modules, OOP, Classes and Standard Library

Part of the Python Mastery Series — Volume 1
"""
import random

class Quiz:
    high_scores = {}   # class-level — shared by ALL Quiz instances

    def __init__(self, title, questions):
        self.title     = title
        self._questions = [dict(q) for q in questions]  # copies

    def randomise(self, seed=None):
        if seed is not None: random.seed(seed)
        random.shuffle(self._questions)
        for q in self._questions:
            random.shuffle(q['options'])
        print('Questions and options randomised.')

    def run(self, num_questions=None):
        questions = self._questions[:num_questions] if num_questions else self._questions
        score, wrong = 0, []
        print(f'\n=== {self.title} ({len(questions)} questions) ===')

        for i, q in enumerate(questions, start=1):
            print(f'\nQ{i}: {q["question"]}')
            for j, opt in enumerate(q['options'], start=1):
                print(f'  {j}) {opt}')
            answer = input('Your answer (1-4): ').strip()
            try:
                chosen = q['options'][int(answer)-1]
            except (ValueError, IndexError):
                print('Invalid input — marked wrong'); chosen = ''
            if chosen == q['answer']:
                print('✅ Correct!'); score += 1
            else:
                print(f'❌ Wrong. Answer: {q["answer"]}')
                wrong.append({'q': q['question'], 'correct': q['answer'], 'you': chosen})
            print(f'Score so far: {score}/{i}')

        pct = score / len(questions) * 100
        print(f'\n=== FINAL: {score}/{len(questions)} ({pct:.0f}%) ===')
        if wrong:
            print('\nReview — questions you missed:')
            for w in wrong: print(f'  Q: {w["q"]}\n    Correct: {w["correct"]}\n    You said: {w["you"] or "(invalid)"}')
        return score, pct

    @classmethod
    def record_high_score(cls, name, score):
        if name not in cls.high_scores or score > cls.high_scores[name]:
            cls.high_scores[name] = score
            print(f'New high score for {name}: {score}')

    @classmethod
    def print_high_scores(cls):
        print('\n=== HIGH SCORES ===')
        for name, score in sorted(cls.high_scores.items(), key=lambda x: -x[1]):
            print(f'  {name}: {score}')