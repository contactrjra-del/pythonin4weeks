"""
Python for Beginners — Week 4
Exercise 3: Simple Counter Class
Difficulty: Easy
Week theme: Modules, OOP, Classes and Standard Library

Part of the Python Mastery Series — Volume 1
"""
class Counter:
    '''A simple counter with increment, decrement, and bounds checking.'''
    def __init__(self, start=0, min_value=None):
        self._count     = start
        self._min_value = min_value

    def increment(self, by=1):
        self._count += by
        return self   # allows chaining: c.increment().increment()

    def decrement(self, by=1):
        new_val = self._count - by
        if self._min_value is not None and new_val < self._min_value:
            raise ValueError(f'Cannot go below {self._min_value} (would be {new_val})')
        self._count = new_val
        return self

    def reset(self):
        self._count = 0
        return self

    def value(self):
        return self._count

    @property
    def is_positive(self): return self._count > 0
    @property
    def is_zero(self):     return self._count == 0
    @property
    def is_negative(self): return self._count < 0

    def __str__(self):  return f'Counter({self._count})'
    def __repr__(self): return f'Counter(start={self._count}, min_value={self._min_value})'

    def __add__(self, other):
        if not isinstance(other, Counter):
            return NotImplemented
        return Counter(self._count + other._count)

# Demo:
c = Counter(0, min_value=0)    # can't go below 0
c.increment().increment(5).increment(3)   # method chaining
print(c)           # Counter(9)
print(c.is_positive)   # True
c.decrement(9)     # Counter(0)
try:
    c.decrement(1)   # ValueError: Cannot go below 0
except ValueError as e:
    print(f'Error: {e}')
c2 = Counter(10); print(c + c2)   # Counter(10)