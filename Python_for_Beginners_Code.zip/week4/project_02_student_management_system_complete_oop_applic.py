"""
Python for Beginners — Week 4
Mini-Project 2: Student Management System — Complete OOP Application
Week theme: Modules, OOP, Classes and Standard Library

This is a capstone project combining all Week 4 concepts.
Run with:  python project_02_student_management_system_complete_oop_applic.py

Part of the Python Mastery Series — Volume 1
"""
'''Student Management System — Week 4 Final Project'''
import csv, math, random
from datetime import date, datetime
from pathlib import Path

class Subject:
    def __init__(self, name, max_score=100):
        self.name      = name.strip()
        self.max_score = max_score
    def __str__(self): return f'{self.name} (max {self.max_score})'
    def __repr__(self): return f'Subject({self.name!r}, max={self.max_score})'

class Student:
    GRADE_MAP = [('A+',97),('A',90),('B+',85),('B',75),('C',60),('D',50),('F',0)]

    def __init__(self, student_id, name, dob_str):
        '''
        Create a new student.
        dob_str: date of birth in YYYY-MM-DD format
        '''
        self.student_id = student_id
        self.name       = name.strip()
        self.dob        = datetime.strptime(dob_str, '%Y-%m-%d').date()
        self._scores    = {}   # {subject_name: score}

    def add_score(self, subject_name, score, max_score=100):
        '''Add or update a subject score. Validates 0 <= score <= max_score.'''
        if not 0 <= score <= max_score:
            raise ValueError(f'Score {score} out of range 0–{max_score}')
        self._scores[subject_name] = round(score, 1)

    def get_average(self):
        '''Return the mean score across all subjects. Returns 0 if no scores.'''
        return round(sum(self._scores.values()) / len(self._scores), 1) if self._scores else 0

    def get_grade(self):
        '''Return letter grade based on average score.'''
        avg = self.get_average()
        for label, cutoff in self.GRADE_MAP:
            if avg >= cutoff: return label
        return 'F'

    def get_age(self):
        '''Return exact age in years.'''
        today = date.today()
        age   = today.year - self.dob.year
        if (today.month, today.day) < (self.dob.month, self.dob.day):
            age -= 1
        return age

    def get_report(self):
        '''Print a formatted student report.'''
        print(f'  Student: {self.name} [{self.student_id}]  Age: {self.get_age()}')
        print(f'  Subjects and Scores:')
        for subj, score in sorted(self._scores.items()):
            bar = '█' * int(score // 5)
            print(f'    {subj:<14}: {score:>5.1f}  {bar}')
        print(f'  Average: {self.get_average():.1f}  Grade: {self.get_grade()}')

    def __str__(self):
        return f'[{self.student_id}] {self.name:<20} avg={self.get_average():>5.1f}  grade={self.get_grade()}'

class StudentDatabase:
    def __init__(self, school_name):
        self.school_name = school_name
        self._students   = {}   # {student_id: Student}
        self._subjects   = {}   # {subject_name: Subject}

    def add_subject(self, name, max_score=100):
        '''Register a subject with the database.'''
        self._subjects[name] = Subject(name, max_score)
        print(f'  Subject added: {name}')

    def enrol(self, student_id, name, dob_str):
        '''Enrol a new student. Raises ValueError if ID already exists.'''
        if student_id in self._students:
            raise ValueError(f'Student ID {student_id} already enrolled')
        s = Student(student_id, name, dob_str)
        self._students[student_id] = s
        print(f'  Enrolled: {s.name} [{student_id}]')
        return s

    def find_student(self, student_id):
        '''Return Student by ID, or None if not found.'''
        return self._students.get(student_id)

    def add_score(self, student_id, subject_name, score):
        '''Add a score for a student in a subject.'''
        s = self._students.get(student_id)
        if not s: raise ValueError(f'Student {student_id} not found')
        subj = self._subjects.get(subject_name)
        max_score = subj.max_score if subj else 100
        s.add_score(subject_name, score, max_score)

    def class_report(self):
        '''Print a complete class report sorted by average descending.'''
        ranked = sorted(self._students.values(), key=lambda s: s.get_average(), reverse=True)
        avgs   = [s.get_average() for s in ranked if s.get_average() > 0]
        class_avg = round(sum(avgs)/len(avgs), 1) if avgs else 0
        print(f'\n=== {self.school_name} — Class Report ({len(self._students)} students) ===')
        print(f"{'Rank':<5} {'Name':<20} {'Avg':>6} {'Grade':>6}")
        print('─'*45)
        for i, s in enumerate(ranked, 1):
            print(f'  #{i:<3} {s.name:<20} {s.get_average():>6.1f} {s.get_grade():>6}')
        print(f'  Class average: {class_avg}')

    def subject_leaderboard(self, subject_name):
        '''Print top performers in a specific subject.'''
        scored = [(s, s._scores[subject_name]) for s in self._students.values() if subject_name in s._scores]
        scored.sort(key=lambda x: -x[1])
        scores = [sc for _,sc in scored]
        print(f'\n=== Leaderboard: {subject_name} ===')
        for i, (s, sc) in enumerate(scored, 1):
            print(f'  #{i}: {s.name:<20} {sc:.1f}')
        if scores:
            print(f'  Mean: {sum(scores)/len(scores):.1f}  High: {max(scores)}  Low: {min(scores)}')

    def honour_roll(self, threshold=85):
        '''Return students with average >= threshold, sorted by average.'''
        honour = sorted([s for s in self._students.values() if s.get_average() >= threshold], key=lambda s: -s.get_average())
        print(f'\n🏆 Honour Roll (avg >= {threshold}): {len(honour)} students')
        for s in honour: print(f'  {s}')
        return honour

    def at_risk_students(self, threshold=50):
        '''Return students with average below threshold.'''
        at_risk = [s for s in self._students.values() if 0 < s.get_average() < threshold]
        print(f'\n⚠  At-Risk Students (avg < {threshold}): {len(at_risk)}')
        for s in at_risk: print(f'  {s}')
        return at_risk

    def export_csv(self, filepath='students_export.csv'):
        '''Export all students and scores to CSV.'''
        subjects = sorted(self._subjects.keys())
        fieldnames = ['student_id','name','dob','age','average','grade'] + subjects
        with open(filepath, 'w', encoding='utf-8', newline='') as f:
            w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction='ignore')
            w.writeheader()
            for s in sorted(self._students.values(), key=lambda s: s.name):
                row = {'student_id':s.student_id,'name':s.name,'dob':s.dob.isoformat(),'age':s.get_age(),'average':s.get_average(),'grade':s.get_grade()}
                for subj in subjects: row[subj] = s._scores.get(subj, '')
                w.writerow(row)
        print(f'Exported {len(self._students)} students to {filepath}')

# ── Demonstration with random data ───────────────────────────────────────
def demo():
    random.seed(42)   # reproducible demo
    db = StudentDatabase('Python Academy')
    subjects_list = ['Maths', 'English', 'Science', 'History', 'Computing']
    for subj in subjects_list: db.add_subject(subj)
    names = [('Alice','2006-03-15'),('Bob','2006-11-22'),('Carol','2007-01-08'),
             ('Dave','2006-09-30'),('Eve','2007-02-14'),('Frank','2006-07-19'),
             ('Grace','2006-12-01'),('Hank','2007-03-25')]
    for i, (name, dob) in enumerate(names, start=1):
        sid = f'S{i:03d}'
        db.enrol(sid, name, dob)
        for subj in subjects_list:
            score = random.gauss(75, 12)   # normal distribution, mean=75, std=12
            score = max(0, min(100, score)) # clamp to 0-100
            db.add_score(sid, subj, score)
    db.class_report()
    db.honour_roll(85)
    db.at_risk_students(55)
    db.subject_leaderboard('Computing')
    student = db.find_student('S001')
    if student: student.get_report()
    db.export_csv()

if __name__ == '__main__':
    demo()
