"""
Python for Beginners — Week 4
Exercise 6: Date-Based Task Scheduler
Difficulty: Medium
Week theme: Modules, OOP, Classes and Standard Library

Part of the Python Mastery Series — Volume 1
"""
from datetime import datetime, date, timedelta

class Task:
    PRIORITY_LABELS = {1:'Low', 2:'Medium', 3:'Normal', 4:'High', 5:'Critical'}

    def __init__(self, title, due_date, priority=3):
        self.title     = title
        self.due_date  = due_date if isinstance(due_date, date) else \
                         datetime.strptime(due_date, '%Y-%m-%d').date()
        if not 1 <= priority <= 5: raise ValueError(f'Priority must be 1-5')
        self.priority   = priority
        self.completed  = False
        self._completed_at = None
        self.created_at = date.today()

    @property
    def days_until_due(self):
        return (self.due_date - date.today()).days
    @property
    def is_overdue(self):
        return not self.completed and self.days_until_due < 0
    @property
    def is_due_today(self):
        return not self.completed and self.days_until_due == 0
    @property
    def priority_label(self):
        return self.PRIORITY_LABELS.get(self.priority, 'Normal')

    def complete(self):
        self.completed     = True
        self._completed_at = datetime.now()
        print(f'✅ Completed: {self.title}')

    def __str__(self):
        status = '✅' if self.completed else ('🔴' if self.is_overdue else ('🟡' if self.is_due_today else '🔵'))
        days   = f'{self.days_until_due:+d}d' if not self.completed else 'done'
        return f'{status} [{self.priority_label:<8}] {self.title:<30} due:{self.due_date} ({days})'

class TaskScheduler:
    def __init__(self): self._tasks = []

    def add_task(self, title, due_date_str, priority=3):
        task = Task(title, due_date_str, priority)
        self._tasks.append(task)
        print(f'Added task: {title} (due {task.due_date})')
        return task

    def complete_task(self, title):
        task = next((t for t in self._tasks if t.title.lower() == title.lower()), None)
        if task: task.complete()
        else: print(f'Task not found: {title!r}')

    def get_overdue(self):
        return sorted([t for t in self._tasks if t.is_overdue], key=lambda t: t.days_until_due)
    def get_due_today(self):
        return [t for t in self._tasks if t.is_due_today]
    def get_upcoming(self, days=7):
        return sorted([t for t in self._tasks if 0 < t.days_until_due <= days], key=lambda t: t.days_until_due)

    def print_dashboard(self):
        overdue  = self.get_overdue()
        today    = self.get_due_today()
        upcoming = self.get_upcoming()
        print('\n=== TASK DASHBOARD ===')
        if overdue:  print(f'🔴 OVERDUE ({len(overdue)}):')
        for t in overdue: print(f'   {t}')
        if today:    print(f'\n🟡 DUE TODAY ({len(today)}):')
        for t in today: print(f'   {t}')
        if upcoming: print(f'\n🔵 UPCOMING ({len(upcoming)}):')
        for t in upcoming: print(f'   {t}')
        done_count = sum(1 for t in self._tasks if t.completed)
        print(f'\nTotal: {len(self._tasks)} tasks | {done_count} completed')