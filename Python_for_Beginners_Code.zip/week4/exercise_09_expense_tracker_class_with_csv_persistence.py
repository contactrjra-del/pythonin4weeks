"""
Python for Beginners — Week 4
Exercise 9: Expense Tracker Class with CSV Persistence
Difficulty: Challenging
Week theme: Modules, OOP, Classes and Standard Library

Part of the Python Mastery Series — Volume 1
"""
import csv
from datetime import date
from pathlib import Path

class Expense:
    def __init__(self, amount, category, description, expense_date=None):
        self.amount      = round(float(amount), 2)
        self.category    = category.strip().title()
        self.description = description.strip()
        self.date        = expense_date or date.today()
        if isinstance(self.date, str):
            from datetime import datetime
            self.date = datetime.strptime(self.date, '%Y-%m-%d').date()

    @property
    def month_key(self): return self.date.strftime('%Y-%m')
    @property
    def formatted_date(self): return self.date.strftime('%d %b %Y')
    def __str__(self):
        return f'{self.formatted_date}  {self.category:<14}  £{self.amount:>8.2f}  {self.description}'

class ExpenseTracker:
    def __init__(self): self._expenses = []

    def add(self, amount, category, description):
        if float(amount) <= 0: raise ValueError('Amount must be positive')
        e = Expense(amount, category, description)
        self._expenses.append(e)
        print(f'Added: £{e.amount:.2f} — {e.category} — {e.description}')
        return e

    def save_to_csv(self, filepath):
        with open(filepath, 'w', encoding='utf-8', newline='') as f:
            w = csv.DictWriter(f, fieldnames=['date','category','description','amount'])
            w.writeheader()
            for e in self._expenses:
                w.writerow({'date':e.date.isoformat(),'category':e.category,'description':e.description,'amount':e.amount})
        print(f'Saved {len(self._expenses)} expenses to {filepath}')

    def load_from_csv(self, filepath):
        if not Path(filepath).exists(): return
        self._expenses = []
        with open(filepath, 'r', encoding='utf-8', newline='') as f:
            for row in csv.DictReader(f):
                self._expenses.append(Expense(row['amount'],row['category'],row['description'],row['date']))
        print(f'Loaded {len(self._expenses)} expenses from {filepath}')

    def monthly_report(self, year, month):
        target  = f'{year}-{month:02d}'
        monthly = [e for e in self._expenses if e.month_key == target]
        if not monthly: print(f'No expenses for {target}'); return
        cat_totals = {}
        for e in monthly: cat_totals[e.category] = cat_totals.get(e.category,0) + e.amount
        grand = sum(cat_totals.values())
        print(f'\n=== {target} — {len(monthly)} expenses ===')
        for e in sorted(monthly, key=lambda x: x.date): print(f'  {e}')
        print('  ' + '─'*50)
        for cat, total in sorted(cat_totals.items(), key=lambda x: -x[1]):
            print(f'  {cat:<14}: £{total:>8.2f}')
        print(f'  TOTAL         : £{grand:>8.2f}')

    def budget_check(self, category, monthly_budget):
        today   = date.today()
        target  = today.strftime('%Y-%m')
        spent   = sum(e.amount for e in self._expenses if e.category.lower()==category.lower() and e.month_key==target)
        pct     = spent / monthly_budget * 100 if monthly_budget > 0 else 0
        status  = '✅ Under' if spent <= monthly_budget else '❌ OVER'
        print(f'{category}: spent £{spent:.2f} / £{monthly_budget:.2f} ({pct:.0f}%) — {status}')
        return spent, monthly_budget

    def search(self, keyword):
        return [e for e in self._expenses if keyword.lower() in e.description.lower() or keyword.lower() in e.category.lower()]

    def top_categories(self, n=5):
        totals = {}
        for e in self._expenses: totals[e.category] = totals.get(e.category,0) + e.amount
        return sorted(totals.items(), key=lambda x: -x[1])[:n]