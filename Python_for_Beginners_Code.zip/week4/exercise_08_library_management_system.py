"""
Python for Beginners — Week 4
Exercise 8: Library Management System
Difficulty: Challenging
Week theme: Modules, OOP, Classes and Standard Library

Part of the Python Mastery Series — Volume 1
"""
from datetime import date, timedelta

class Book:
    def __init__(self, isbn, title, author, year, genre, copies=1):
        self.isbn             = isbn
        self.title            = title
        self.author           = author
        self.year             = year
        self.genre            = genre
        self.copies_total     = copies
        self.copies_available = copies

    def check_out(self):
        if self.copies_available < 1:
            raise ValueError(f'No copies of {self.title!r} available')
        self.copies_available -= 1

    def return_book(self):
        if self.copies_available >= self.copies_total:
            raise ValueError(f'All copies already returned for {self.title!r}')
        self.copies_available += 1

    @property
    def is_available(self): return self.copies_available > 0
    @property
    def availability_string(self): return f'{self.copies_available}/{self.copies_total}'
    def __str__(self):
        return f'[{self.isbn}] {self.title} by {self.author} ({self.year}) [{self.genre}] avail:{self.availability_string}'

class Member:
    LOAN_PERIOD_DAYS = 14

    def __init__(self, member_id, name, email):
        self.member_id  = member_id
        self.name       = name
        self.email      = email
        self.join_date  = date.today()
        self._borrowed  = []   # list of {isbn, title, borrow_date, due_date}

    def borrow(self, book):
        book.check_out()
        self._borrowed.append({
            'isbn':        book.isbn,
            'title':       book.title,
            'borrow_date': date.today(),
            'due_date':    date.today() + timedelta(days=self.LOAN_PERIOD_DAYS),
        })
        print(f'{self.name} borrowed {book.title!r} (due {self._borrowed[-1]["due_date"]})')

    def return_book(self, isbn):
        record = next((r for r in self._borrowed if r['isbn'] == isbn), None)
        if not record:
            raise ValueError(f'{self.name} has not borrowed ISBN {isbn}')
        self._borrowed.remove(record)
        return record

    @property
    def borrowed_count(self): return len(self._borrowed)
    @property
    def has_overdue(self): return any(r['due_date'] < date.today() for r in self._borrowed)
    def __str__(self): return f'[{self.member_id}] {self.name} | {self.email} | {self.borrowed_count} books borrowed'

class Library:
    def __init__(self, name):
        self.name     = name
        self._books   = {}
        self._members = {}

    def add_book(self, book): self._books[book.isbn] = book
    def add_member(self, member): self._members[member.member_id] = member

    def _get_book(self, isbn):
        b = self._books.get(isbn)
        if not b: raise ValueError(f'Book ISBN {isbn} not found')
        return b
    def _get_member(self, member_id):
        m = self._members.get(member_id)
        if not m: raise ValueError(f'Member {member_id} not found')
        return m

    def search_by_title(self, query):
        return [b for b in self._books.values() if query.lower() in b.title.lower()]
    def search_by_author(self, query):
        return [b for b in self._books.values() if query.lower() in b.author.lower()]

    def borrow_book(self, member_id, isbn):
        member = self._get_member(member_id)
        book   = self._get_book(isbn)
        member.borrow(book)

    def return_book(self, member_id, isbn):
        member = self._get_member(member_id)
        book   = self._get_book(isbn)
        record = member.return_book(isbn)
        book.return_book()
        days_overdue = (date.today() - record['due_date']).days
        if days_overdue > 0: print(f'⚠  Returned {days_overdue} day(s) overdue')
        else: print(f'✅ {book.title!r} returned by {member.name}')

    def overdue_report(self):
        overdue = [(m, r) for m in self._members.values() for r in m._borrowed if r['due_date'] < date.today()]
        if not overdue: print('No overdue books.'); return
        print(f'OVERDUE REPORT ({len(overdue)} books):')
        for m, r in overdue:
            days = (date.today() - r['due_date']).days
            print(f'  {m.name}: {r["title"]!r} — {days}d overdue (due {r["due_date"]})')

    def availability_report(self):
        print(f'\n=== {self.name} — Availability ===')
        for book in sorted(self._books.values(), key=lambda b: b.title):
            marker = '' if book.is_available else ' (UNAVAILABLE)'
            print(f'  {book}{marker}')