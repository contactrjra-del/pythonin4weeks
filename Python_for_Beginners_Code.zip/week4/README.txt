Week 4 — Modules, OOP, Classes and Standard Library
============================================================

Topics covered this week:
  • math, random, os, sys modules
  • datetime module
  • Classes and OOP (Week 4)
  • @property and static methods
  • pip and virtual environments

Files in this folder:
----------------------------------------
  exercise_01_dice_roller_simulator.py  — Dice Roller Simulator [Easy]
  exercise_02_datetime_calendar_utility.py  — datetime Calendar Utility [Easy]
  exercise_03_simple_counter_class.py  — Simple Counter Class [Easy]
  exercise_04_product_catalogue_class.py  — Product Catalogue Class [Medium]
  exercise_05_statistics_library_using_math_module.py  — Statistics Library Using math Module [Medium]
  exercise_06_date_based_task_scheduler.py  — Date-Based Task Scheduler [Medium]
  exercise_07_random_quiz_generator.py  — Random Quiz Generator [Medium]
  exercise_08_library_management_system.py  — Library Management System [Challenging]
  exercise_09_expense_tracker_class_with_csv_persistence.py  — Expense Tracker Class with CSV Persistence [Challenging]
  exercise_10_number_analysis_suite_classes_math_module.py  — Number Analysis Suite — Classes + math Module [Challenging]
  project_01_personal_expense_tracker_oop_file_backed.py       — Personal Expense Tracker — OOP & File-Backed
  project_02_student_management_system_complete_oop_applic.py       — Student Management System — Complete OOP Application