Python for Beginners — Complete Code Repository
====================================================

This ZIP contains all runnable Python source code from
'Python for Beginners: A Complete Self-Study Programme'.

Structure:
  week1/  exercises 01-10 + 2 projects  (Variables, types, strings, conditionals)
  week2/  exercises 01-10 + 2 projects  (Lists, dicts, sets, loops, comprehensions)
  week3/  exercises 01-10 + 2 projects  (Functions, files, CSV, error handling)
  week4/  exercises 01-10 + 2 projects  (Modules, datetime, OOP, pip/venv)

Running any file:
  python week1/exercise_01_personal_introduction.py

Requirements:
  Python 3.10+  (no third-party packages needed for any exercise)

Contents:
----------------------------------------

WEEK 1
  exercise_01_personal_introduction_program.py  [Easy]
  exercise_02_temperature_converter.py  [Easy]
  exercise_03_string_inspector.py  [Easy]
  exercise_04_shop_bill_calculator.py  [Medium]
  exercise_05_leap_year_detector.py  [Medium]
  exercise_06_password_strength_checker.py  [Medium]
  exercise_07_number_properties_analyser.py  [Medium]
  exercise_08_simple_atm_simulator.py  [Challenging]
  exercise_09_mortgage_payment_calculator.py  [Challenging]
  exercise_10_text_analyser_—_sentence_statistics.py  [Challenging]
  project_01_bank_account_balance_checker_and_advisor.py
  project_02_username_and_password_generator.py

WEEK 2
  exercise_01_list_basics_—_five_operations.py  [Easy]
  exercise_02_dictionary_—_student_record.py  [Easy]
  exercise_03_set_operations_—_mailing_list_deduplicat.py  [Easy]
  exercise_04_for_loop_—_times_table_generator.py  [Medium]
  exercise_05_dictionary_—_word_frequency_counter.py  [Medium]
  exercise_06_while_loop_—_number_guessing_game.py  [Medium]
  exercise_07_list_comprehension_—_data_transformation.py  [Medium]
  exercise_08_nested_collections_—_class_results_proce.py  [Challenging]
  exercise_09_inventory_management_system.py  [Challenging]
  exercise_10_contact_book_with_search_and_statistics.py  [Challenging]
  project_01_student_grade_report_generator.py
  project_02_supermarket_self-checkout_system.py

WEEK 3
  exercise_01_temperature_conversion_library.py  [Easy]
  exercise_02_text_file_word_counter.py  [Easy]
  exercise_03_student_average_calculator_(csv).py  [Easy]
  exercise_04_function:_fibonacci_with_memoisation.py  [Medium]
  exercise_05_file_log_analyser.py  [Medium]
  exercise_06_recursive_directory_tree.py  [Medium]
  exercise_07_safe_input_function_library.py  [Medium]
  exercise_08_csv_data_merger_and_deduplicator.py  [Challenging]
  exercise_09_multi-file_report_generator.py  [Challenging]
  exercise_10_personal_finance_tracker_—_file-backed.py  [Challenging]
  project_01_csv_sales_data_reporter.py
  project_02_text_file_manager_with_functions.py

WEEK 4
  exercise_01_dice_roller_simulator.py  [Easy]
  exercise_02_datetime_calendar_utility.py  [Easy]
  exercise_03_simple_counter_class.py  [Easy]
  exercise_04_product_catalogue_class.py  [Medium]
  exercise_05_statistics_library_using_math_module.py  [Medium]
  exercise_06_date-based_task_scheduler.py  [Medium]
  exercise_07_random_quiz_generator.py  [Medium]
  exercise_08_library_management_system.py  [Challenging]
  exercise_09_expense_tracker_class_with_csv_persisten.py  [Challenging]
  exercise_10_number_analysis_suite_—_classes_+_math_m.py  [Challenging]
  project_01_personal_expense_tracker_—_oop_and_file-.py
  project_02_student_management_system_—_complete_oop.py

Happy coding! — Python Mastery Series, Volume 1